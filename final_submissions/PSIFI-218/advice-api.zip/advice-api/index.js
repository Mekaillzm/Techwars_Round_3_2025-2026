const express = require("express");
const app = express();
const port = 5560;

const adviceList = [
  "Dance like nobody's watching, even if your cat judges you.",
  "Never trust a dog to guard your sandwich.",
  "If life gives you lemons, make lemonade… then add some tequila.",
  "Always high-five yourself in the mirror at least once a day.",
  "Take a nap — productivity loves the well-rested.",
  "Talk to your plants, they might be plotting something.",
  "Wear socks that make you happy. Even your toes deserve joy.",
  "Sing in the shower like you're headlining a stadium.",
  "Buy a random souvenir for no reason at all. Memories > money.",
  "Smash one mundane task first; then reward yourself with chocolate.",
  "Pretend you're a secret agent while taking out the trash.",
  "Laugh at your mistakes. They're comedy gold.",
  "Invent a new handshake. Bonus points if pets understand it.",
  "Try a new food combo — pickles and peanut butter, maybe?",
  "Write a thank-you note to your past self for surviving Monday.",
];

app.get("/advice", (req, res) => {
  const randomIndex = Math.floor(Math.random() * adviceList.length);
  const advice = adviceList[randomIndex];
  res.json({ advice });
});

app.get("/", (req, res) => {
  res.send("Advice API is running!");
});

app.listen(port, () => {
  console.log(`Advice API running at http://localhost:${port}`);
});
