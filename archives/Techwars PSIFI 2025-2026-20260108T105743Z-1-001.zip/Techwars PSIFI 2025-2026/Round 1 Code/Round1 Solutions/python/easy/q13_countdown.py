"""
Q13 (Python): Countdown debugging exercise
SOLUTION
"""
from typing import List, Union


def countdown(start: int) -> List[Union[int, str]]:
    result = []
    i = start
    
    while i > 0:
        result.append(i)
        i -= 1  # Fixed: Added decrement
    
    result.append("Liftoff!")
    return result
