"""
Q20 (Python): Scope bug debugging exercise
SOLUTION
"""


def calculate_total(should_calculate: bool, base: int, addition: int) -> int:
    total = 0  # Fixed: Initialize total outside of if block
    
    if should_calculate:
        total = base + addition
    
    return total
