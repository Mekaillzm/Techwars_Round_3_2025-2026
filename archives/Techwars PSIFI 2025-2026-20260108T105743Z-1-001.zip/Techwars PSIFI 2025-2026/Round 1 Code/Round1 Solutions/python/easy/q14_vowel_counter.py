"""
Q14 (Python): Vowel Counter
SOLUTION
"""


def count_vowels(s: str) -> int:
    count = 0
    vowels = "aeiouAEIOU"
    
    for char in s:
        if char in vowels:
            count += 1
    
    return count
