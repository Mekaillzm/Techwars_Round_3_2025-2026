"""
Q15 (Python): Percentage calculation debugging exercise
SOLUTION
"""


def calculate_percentage(obtained: int, total: int) -> float:
    # Fixed: Use / instead of // for proper float division
    percentage = (obtained / total) * 100
    return percentage
