"""
Q18 (Python): Array access debugging exercise
SOLUTION
"""
from typing import List


def get_last_element(arr: List[int]) -> int:
    if not arr:
        raise ValueError("empty array")
    
    return arr[-1]  # Fixed: Use -1 or arr[len(arr) - 1]
