"""
Q1 (Python): Simulate pointer-like swap and offset operations on a mutable container.
SOLUTION
"""

from typing import List, Any


def swap_by_index(arr: List[Any], i: int, j: int) -> None:
    arr[i], arr[j] = arr[j], arr[i]


def get_offset_value(arr: List[Any], base_index: int, offset: int) -> Any:
    return arr[base_index + offset]
