"""
Q10 (Python): Statistics — mean, median, and range calculations.
SOLUTION
"""
from typing import List


def calc_mean(arr: List[int]) -> float:
    if not arr:
        raise ValueError("empty array")
    return sum(arr) / len(arr)


def calc_median(arr: List[int]) -> float:
    if not arr:
        raise ValueError("empty array")
    
    sorted_arr = sorted(arr)
    n = len(sorted_arr)
    
    if n % 2 == 0:
        return (sorted_arr[n // 2 - 1] + sorted_arr[n // 2]) / 2.0
    else:
        return sorted_arr[n // 2]


def calc_range(arr: List[int]) -> int:
    if not arr:
        raise ValueError("empty array")
    return max(arr) - min(arr)
