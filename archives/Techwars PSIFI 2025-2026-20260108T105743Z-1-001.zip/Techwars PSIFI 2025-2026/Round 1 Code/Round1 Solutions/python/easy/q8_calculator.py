"""
Q8 (Python): Calculator operations.
SOLUTION
"""


def add(a: int, b: int) -> int:
    return a + b


def subtract(a: int, b: int) -> int:
    return a - b


def multiply(a: int, b: int) -> int:
    return a * b


def integer_divide(a: int, b: int) -> int:
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a // b


def real_divide(a: float, b: float) -> float:
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b


def power(base: int, exp: int) -> float:
    return base ** exp


def modulo(a: int, b: int) -> int:
    if b == 0:
        raise ZeroDivisionError("modulo by zero")
    return a % b
