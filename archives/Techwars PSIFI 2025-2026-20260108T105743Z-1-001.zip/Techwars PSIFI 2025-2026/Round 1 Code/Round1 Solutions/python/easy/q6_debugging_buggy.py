"""
Q6 (Python): Debugging — fixed implementation.
SOLUTION
"""
from typing import List


def find_max(arr: List[int]) -> int:
    if not arr:
        raise ValueError("empty array")
    
    m = arr[0]  # Fixed: Initialize with first element
    for x in arr:
        if x > m:  # Fixed: Correct comparison
            m = x
    return m


def safe_divide(a: float, b: float) -> float:
    if b == 0:
        raise ZeroDivisionError("division by zero")
    return a / b
