"""
Q11 (Python): Symbol pattern generation.
SOLUTION
"""


def generate_symbol_pattern(a: int, b: int) -> str:
    larger = max(a, b)
    smaller = min(a, b)
    
    if smaller == 0:
        return ""
    
    limit = larger // smaller
    
    result = ""
    for i in range(1, limit + 1):
        if i % 10 == 0:
            result += '*'
        elif i % 5 == 0:
            result += '#'
        else:
            result += '-'
    
    return result
