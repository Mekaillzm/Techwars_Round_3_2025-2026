"""
Q16 (Python): Find largest element
SOLUTION
"""
from typing import List


def find_largest(arr: List[int]) -> int:
    if not arr:
        raise ValueError("empty array")
    
    largest = arr[0]
    
    for x in arr:
        if x > largest:
            largest = x
    
    return largest
