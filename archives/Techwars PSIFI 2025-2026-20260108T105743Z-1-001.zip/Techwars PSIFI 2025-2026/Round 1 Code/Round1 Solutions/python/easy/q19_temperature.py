"""
Q19 (Python): Temperature conversion
SOLUTION
"""


def fahrenheit_to_celsius(fahrenheit: float) -> float:
    return (fahrenheit - 32) * 5 / 9


def celsius_to_fahrenheit(celsius: float) -> float:
    return celsius * 9 / 5 + 32
