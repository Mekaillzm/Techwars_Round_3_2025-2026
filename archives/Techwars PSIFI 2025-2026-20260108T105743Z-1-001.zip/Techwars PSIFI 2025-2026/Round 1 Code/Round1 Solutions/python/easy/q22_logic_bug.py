"""
Q22 (Python): Logic bug debugging exercise (AND vs OR)
SOLUTION
"""


def is_yes(char: str) -> bool:
    # Fixed: Use 'or' instead of 'and'
    if char == 'Y' or char == 'y':
        return True
    return False
