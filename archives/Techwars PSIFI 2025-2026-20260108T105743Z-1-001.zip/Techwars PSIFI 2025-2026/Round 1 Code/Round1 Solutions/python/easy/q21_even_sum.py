"""
Q21 (Python): Sum of even numbers
SOLUTION
"""


def sum_of_evens(n: int) -> int:
    total = 0
    
    for i in range(2, n + 1, 2):
        total += i
    
    return total
