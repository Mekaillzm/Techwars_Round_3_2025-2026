"""
Q5 (Python): OOP — implement a simple bank account hierarchy.
SOLUTION
"""


class BankAccount:
    def __init__(self, initial: float = 0.0):
        self._balance = initial

    def deposit(self, amount: float) -> None:
        if amount < 0:
            raise ValueError("Cannot deposit negative amount")
        self._balance += amount

    def withdraw(self, amount: float) -> None:
        if amount < 0:
            raise ValueError("Cannot withdraw negative amount")
        if amount > self._balance:
            raise ValueError("Overdraft not allowed")
        self._balance -= amount

    def balance(self) -> float:
        return self._balance


class SavingsAccount(BankAccount):
    def __init__(self, initial: float = 0.0, interest_rate: float = 0.01):
        super().__init__(initial)
        self._rate = interest_rate

    def apply_interest(self) -> None:
        self._balance += self._balance * self._rate
