"""
Q31 (Python): Reverse a singly linked list
SOLUTION
"""
from typing import Optional, List


class ListNode:
    def __init__(self, val: int):
        self.val = val
        self.next: Optional['ListNode'] = None


def reverse_list(head: Optional[ListNode]) -> Optional[ListNode]:
    prev = None
    curr = head
    
    while curr is not None:
        next_node = curr.next
        curr.next = prev
        prev = curr
        curr = next_node
    
    return prev


def create_list(arr: List[int]) -> Optional[ListNode]:
    """Helper to create list from array (for testing)"""
    if not arr:
        return None
    head = ListNode(arr[0])
    curr = head
    for val in arr[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def list_to_array(head: Optional[ListNode]) -> List[int]:
    """Helper to convert list to array (for testing)"""
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result
