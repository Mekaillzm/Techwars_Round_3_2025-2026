"""
Q3 (Python): Implement data structures.
SOLUTION
"""
from typing import List, Any


class Stack:
    def __init__(self):
        self._data: List[Any] = []

    def push(self, x: Any) -> None:
        self._data.append(x)

    def pop(self) -> Any:
        if self._data:
            return self._data.pop()
        return None

    def peek(self) -> Any:
        if self._data:
            return self._data[-1]
        return None

    def is_empty(self) -> bool:
        return len(self._data) == 0


class Queue:
    def __init__(self):
        self._data: List[Any] = []

    def enqueue(self, x: Any) -> None:
        self._data.append(x)

    def dequeue(self) -> Any:
        if self._data:
            return self._data.pop(0)
        return None

    def peek(self) -> Any:
        if self._data:
            return self._data[0]
        return None

    def is_empty(self) -> bool:
        return len(self._data) == 0


def stack_using_queues():
    """Optional: Implement stack using two queues"""
    pass


def queue_using_stacks():
    """Optional: Implement queue using two stacks"""
    pass
