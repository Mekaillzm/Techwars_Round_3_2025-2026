"""
Q33 (Python): Deep copy vs shallow copy (analogous to C++ copy constructor)
SOLUTION
"""
from typing import List
import copy


class IntWrapper:
    """Class that wraps a list of integers - demonstrates shallow vs deep copy"""
    
    def __init__(self, values: List[int]):
        self.values = values.copy()  # Fixed: Make a copy to avoid shared reference
    
    def get_values(self) -> List[int]:
        return self.values
    
    def set_value(self, index: int, val: int) -> None:
        self.values[index] = val
    
    def deep_copy(self) -> 'IntWrapper':
        """Create a proper deep copy"""
        return IntWrapper(self.values.copy())


def demonstrate_shallow_copy_bug():
    """Shows the bug: modifying copy affects original"""
    original = IntWrapper([1, 2, 3])
    shallow = original  # This is just a reference, not a copy!
    
    shallow.set_value(0, 999)
    # Now original.values[0] is also 999!
    
    return original.get_values()[0] == 999  # True - bug!


def demonstrate_deep_copy_fix():
    """Shows the fix: deep copy is independent"""
    original = IntWrapper([1, 2, 3])
    deep = original.deep_copy()
    
    deep.set_value(0, 999)
    # original.values[0] is still 1
    
    return original.get_values()[0] == 1  # True - fixed!
