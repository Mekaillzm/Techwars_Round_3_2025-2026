"""
Q9 (Python): Binary addition of two binary strings.
SOLUTION
"""


def binary_addition(x: str, y: str) -> str:
    result = ""
    carry = 0
    
    i = len(x) - 1
    j = len(y) - 1
    
    while i >= 0 or j >= 0 or carry:
        total = carry
        
        if i >= 0:
            total += int(x[i])
            i -= 1
        if j >= 0:
            total += int(y[j])
            j -= 1
        
        carry = total // 2
        result = str(total % 2) + result
    
    return result
