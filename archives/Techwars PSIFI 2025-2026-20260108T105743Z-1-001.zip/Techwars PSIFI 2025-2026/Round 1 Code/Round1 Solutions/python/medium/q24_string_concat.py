"""
Q24 (Python): String concatenation type error debugging exercise
SOLUTION
"""


def create_introduction(name: str, age: int) -> str:
    # Fixed: Convert age to string with str()
    return "My name is " + name + " and I am " + str(age) + " years old."
