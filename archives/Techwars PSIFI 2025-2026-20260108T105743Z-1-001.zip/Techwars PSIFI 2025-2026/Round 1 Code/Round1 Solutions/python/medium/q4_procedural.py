"""
Q4 (Python): Procedural programming — matrix transpose and rotate operations.
SOLUTION
"""
from typing import List


def transpose(matrix: List[List[int]]) -> List[List[int]]:
    if not matrix:
        return []
    
    rows = len(matrix)
    cols = len(matrix[0])
    
    result = [[0] * rows for _ in range(cols)]
    
    for i in range(rows):
        for j in range(cols):
            result[j][i] = matrix[i][j]
    
    return result


def rotate_right(matrix: List[List[int]]) -> List[List[int]]:
    # Transpose then reverse each row
    t = transpose(matrix)
    for row in t:
        row.reverse()
    return t
