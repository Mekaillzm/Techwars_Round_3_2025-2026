"""
Q7 (Python): Caesar cipher - all shifts
SOLUTION
"""
from typing import List


def shift_char(c: str, sh: int) -> str:
    if 'a' <= c <= 'z':
        return chr((ord(c) - ord('a') + sh) % 26 + ord('a'))
    if 'A' <= c <= 'Z':
        return chr((ord(c) - ord('A') + sh) % 26 + ord('A'))
    return c


def all_caesar_shifts(s: str) -> List[str]:
    out: List[str] = []
    
    for sh in range(26):
        shifted = ''.join(shift_char(c, sh) for c in s)
        out.append(shifted)
    
    return out
