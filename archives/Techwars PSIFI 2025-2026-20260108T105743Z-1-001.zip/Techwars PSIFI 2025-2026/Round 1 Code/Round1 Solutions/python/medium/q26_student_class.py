"""
Q26 (Python): Student class OOP
SOLUTION
"""


class Student:
    def __init__(self, name: str, student_id: int, gpa: float):
        self._name = name
        self._id = student_id
        self._gpa = gpa
    
    def get_name(self) -> str:
        return self._name
    
    def get_id(self) -> int:
        return self._id
    
    def get_gpa(self) -> float:
        return self._gpa
    
    def is_honors(self) -> bool:
        return self._gpa > 3.5
