"""
Q28 (Python): Recursive factorial
SOLUTION
"""


def factorial(n: int) -> int:
    if n < 0:
        return -1
    if n == 0 or n == 1:
        return 1
    return n * factorial(n - 1)
