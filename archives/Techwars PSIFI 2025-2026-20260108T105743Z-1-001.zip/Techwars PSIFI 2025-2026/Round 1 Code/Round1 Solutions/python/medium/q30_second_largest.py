"""
Q30 (Python): Find second largest element
SOLUTION
"""
from typing import List


def find_second_largest(arr: List[int]) -> int:
    if len(arr) < 2:
        raise ValueError("need at least 2 elements")
    
    largest = float('-inf')
    second = float('-inf')
    
    for x in arr:
        if x > largest:
            second = largest
            largest = x
        elif x > second and x != largest:
            second = x
    
    if second == float('-inf'):
        raise ValueError("need at least 2 distinct elements")
    
    return second
