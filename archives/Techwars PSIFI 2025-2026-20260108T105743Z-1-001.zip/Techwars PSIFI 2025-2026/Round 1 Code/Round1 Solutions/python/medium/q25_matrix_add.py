"""
Q25 (Python): Matrix addition
SOLUTION
"""
from typing import List


def matrix_add(a: List[List[int]], b: List[List[int]]) -> List[List[int]]:
    if not a:
        return []
    
    rows = len(a)
    cols = len(a[0])
    
    result = [[0] * cols for _ in range(rows)]
    
    for i in range(rows):
        for j in range(cols):
            result[i][j] = a[i][j] + b[i][j]
    
    return result
