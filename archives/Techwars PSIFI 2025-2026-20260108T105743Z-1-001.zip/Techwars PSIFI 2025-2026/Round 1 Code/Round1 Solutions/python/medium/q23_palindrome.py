"""
Q23 (Python): Palindrome checker
SOLUTION
"""


def is_palindrome(s: str) -> bool:
    # Filter to only alphanumeric and lowercase
    filtered = ''.join(c.lower() for c in s if c.isalnum())
    
    # Check palindrome with two pointers
    left = 0
    right = len(filtered) - 1
    
    while left < right:
        if filtered[left] != filtered[right]:
            return False
        left += 1
        right -= 1
    
    return True
