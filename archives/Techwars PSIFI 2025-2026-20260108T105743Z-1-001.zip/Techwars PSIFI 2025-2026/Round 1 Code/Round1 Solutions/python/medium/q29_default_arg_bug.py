"""
Q29 (Python): Mutable default argument bug
SOLUTION
"""
from typing import List, Optional


def add_student_buggy(student_name: str, student_list: List[str] = []) -> List[str]:
    # BUGGY: Mutable default argument - the list persists between calls!
    student_list.append(student_name)
    return student_list


def add_student_fixed(student_name: str, student_list: Optional[List[str]] = None) -> List[str]:
    # Fixed: Use None as default and create new list if needed
    if student_list is None:
        student_list = []
    student_list.append(student_name)
    return student_list
