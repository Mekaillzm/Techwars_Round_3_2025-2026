"""
Q2 (Python): Singly linked list implementation.
SOLUTION
"""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class Node:
    value: int
    next: Optional['Node'] = None


class LinkedList:
    def __init__(self):
        self.head: Optional[Node] = None

    def insert_at_head(self, value: int) -> None:
        new_node = Node(value)
        new_node.next = self.head
        self.head = new_node
    
    def insert_at_tail(self, value: int) -> None:
        new_node = Node(value)
        if not self.head:
            self.head = new_node
            return
        
        curr = self.head
        while curr.next:
            curr = curr.next
        curr.next = new_node

    def delete_value(self, value: int) -> bool:
        if not self.head:
            return False
        
        if self.head.value == value:
            self.head = self.head.next
            return True
        
        curr = self.head
        while curr.next:
            if curr.next.value == value:
                curr.next = curr.next.next
                return True
            curr = curr.next
        
        return False

    def to_list(self) -> List[int]:
        result = []
        curr = self.head
        while curr:
            result.append(curr.value)
            curr = curr.next
        return result
