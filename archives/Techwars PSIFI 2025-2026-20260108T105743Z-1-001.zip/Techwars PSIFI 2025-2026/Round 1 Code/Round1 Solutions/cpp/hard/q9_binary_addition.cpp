#include "q9_binary_addition.h"

std::string binary_addition(const std::string& x, const std::string& y) {
    std::string result = "";
    int carry = 0;
    
    int i = x.size() - 1;
    int j = y.size() - 1;
    
    while (i >= 0 || j >= 0 || carry) {
        int sum = carry;
        
        if (i >= 0) {
            sum += x[i] - '0';
            i--;
        }
        if (j >= 0) {
            sum += y[j] - '0';
            j--;
        }
        
        carry = sum / 2;
        result = char('0' + (sum % 2)) + result;
    }
    
    return result;
}
