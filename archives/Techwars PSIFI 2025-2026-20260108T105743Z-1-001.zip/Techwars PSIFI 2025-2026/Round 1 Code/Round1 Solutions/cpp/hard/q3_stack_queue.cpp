#include "q3_stack_queue.h"
#include <stdexcept>

Stack::Stack() {}

void Stack::push(int x) { 
    data.push_back(x); 
}

int Stack::pop() {
    if (data.empty()) return 0;
    int v = data.back(); 
    data.pop_back(); 
    return v;
}

int Stack::peek() const { 
    if (data.empty()) return 0; 
    return data.back(); 
}

bool Stack::is_empty() const { 
    return data.empty(); 
}

Queue::Queue() {}

void Queue::enqueue(int x) { 
    data.push_back(x); 
}

int Queue::dequeue() {
    if (data.empty()) return 0;
    int v = data.front();
    data.erase(data.begin());
    return v;
}

int Queue::peek() const {
    if (data.empty()) return 0;
    return data.front();
}

bool Queue::is_empty() const { 
    return data.empty(); 
}
