#ifndef Q31_REVERSE_LIST_H
#define Q31_REVERSE_LIST_H

struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};

ListNode* reverse_list(ListNode* head);
ListNode* create_list(const int* arr, int size);
void free_list(ListNode* head);

#endif
