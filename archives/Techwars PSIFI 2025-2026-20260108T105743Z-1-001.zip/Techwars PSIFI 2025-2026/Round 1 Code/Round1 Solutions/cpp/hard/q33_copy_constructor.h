#ifndef Q33_COPY_CONSTRUCTOR_H
#define Q33_COPY_CONSTRUCTOR_H

class IntArray {
public:
    IntArray(int val);
    IntArray(const IntArray& other);  // Fixed: Added copy constructor
    ~IntArray();
    
    int getValue() const;
    void setValue(int val);

private:
    int* ptr;
};

#endif
