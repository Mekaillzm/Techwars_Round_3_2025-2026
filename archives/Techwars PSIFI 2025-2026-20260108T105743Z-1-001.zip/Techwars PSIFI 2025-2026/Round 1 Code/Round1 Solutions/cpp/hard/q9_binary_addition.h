#ifndef Q9_BINARY_ADDITION_H
#define Q9_BINARY_ADDITION_H

#include <string>

std::string binary_addition(const std::string& x, const std::string& y);

#endif
