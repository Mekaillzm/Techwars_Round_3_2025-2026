#include "q33_copy_constructor.h"
#include <iostream>

IntArray::IntArray(int val) {
    ptr = new int;
    *ptr = val;
}

// Fixed: Added copy constructor to prevent double-free
IntArray::IntArray(const IntArray& other) {
    ptr = new int;
    *ptr = *(other.ptr);
}

IntArray::~IntArray() {
    delete ptr;
}

int IntArray::getValue() const {
    return *ptr;
}

void IntArray::setValue(int val) {
    *ptr = val;
}
