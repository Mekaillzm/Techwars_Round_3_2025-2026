#ifndef Q32_BINARY_SEARCH_H
#define Q32_BINARY_SEARCH_H

int binary_search(const int* arr, int size, int target);

#endif
