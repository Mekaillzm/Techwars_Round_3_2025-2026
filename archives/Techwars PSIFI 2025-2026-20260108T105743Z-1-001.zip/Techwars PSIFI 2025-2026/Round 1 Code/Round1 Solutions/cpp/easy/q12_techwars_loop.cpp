#include "q12_techwars_loop.h"

std::vector<std::string> techwars_sequence(int n) {
    std::vector<std::string> result;
    
    for (int i = 1; i <= n; ++i) {
        if (i % 15 == 0) {
            result.push_back("TechWars");
        } else if (i % 3 == 0) {
            result.push_back("Tech");
        } else if (i % 5 == 0) {
            result.push_back("Wars");
        } else {
            result.push_back(std::to_string(i));
        }
    }
    
    return result;
}
