#ifndef Q17_LEAP_YEAR_H
#define Q17_LEAP_YEAR_H

bool is_leap_year(int year);

#endif
