#include "q1_pointers.h"


void swap_by_ptrs(int* a, int* b) {
    if (!a || !b) return;
    
    if (a != b) {
        int tmp = *a;
        *a = *b;
        *b = tmp;
    }
}

int get_offset_value(int* arr, int base_index, int offset, int size) {
    int i = base_index + offset;

    if (!arr || i < 0 || i >= size) return 0;

    return *(arr + i);
}
