#ifndef Q16_FIND_LARGEST_H
#define Q16_FIND_LARGEST_H

#include <vector>

int find_largest(const std::vector<int>& arr);

#endif
