#include "q22_logic_bug.h"

bool is_yes(char input) {
    // Fixed: Use || instead of && - char cannot be both 'Y' and 'y' at once
    if (input == 'Y' || input == 'y') {
        return true;
    }
    return false;
}
