#ifndef Q20_SCOPE_BUG_H
#define Q20_SCOPE_BUG_H

int calculate_total(bool should_calculate, int base, int addition);

#endif
