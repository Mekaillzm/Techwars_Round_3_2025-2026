#ifndef Q1_POINTERS_H
#define Q1_POINTERS_H

void swap_by_ptrs(int* a, int* b);
int get_offset_value(int* arr, int base_index, int offset, int size);

#endif
