#ifndef Q12_TECHWARS_LOOP_H
#define Q12_TECHWARS_LOOP_H

#include <vector>
#include <string>

std::vector<std::string> techwars_sequence(int n);

#endif
