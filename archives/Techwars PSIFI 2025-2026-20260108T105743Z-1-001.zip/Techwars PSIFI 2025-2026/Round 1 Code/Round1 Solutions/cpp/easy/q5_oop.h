#ifndef Q5_OOP_H
#define Q5_OOP_H

class BankAccount {
protected:
    double bal;
public:
    BankAccount(double initial = 0.0);
    virtual ~BankAccount();
    void deposit(double amount);
    void withdraw(double amount);
    double balance() const;
};

class SavingsAccount : public BankAccount {
protected:
    double rate;
public:
    SavingsAccount(double initial = 0.0, double interest_rate = 0.01);
    void apply_interest();
};

#endif
