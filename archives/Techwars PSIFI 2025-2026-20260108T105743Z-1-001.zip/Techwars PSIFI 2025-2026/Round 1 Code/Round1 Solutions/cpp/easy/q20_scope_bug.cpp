#include "q20_scope_bug.h"

int calculate_total(bool should_calculate, int base, int addition) {
    int total = 0;  // Fixed: Declare total outside of if block
    
    if (should_calculate) {
        total = base + addition;
    }
    
    return total;
}
