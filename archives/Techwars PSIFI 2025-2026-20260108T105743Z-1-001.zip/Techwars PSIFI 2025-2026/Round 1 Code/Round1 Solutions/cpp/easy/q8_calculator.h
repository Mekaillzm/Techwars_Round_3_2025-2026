#ifndef Q8_CALCULATOR_H
#define Q8_CALCULATOR_H

int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);
int integer_divide(int a, int b);
double real_divide(double a, double b);
double power(int base, int exp);
int modulo(int a, int b);

#endif
