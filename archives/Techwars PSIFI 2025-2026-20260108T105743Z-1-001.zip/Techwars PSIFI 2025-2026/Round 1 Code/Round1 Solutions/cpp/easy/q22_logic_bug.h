#ifndef Q22_LOGIC_BUG_H
#define Q22_LOGIC_BUG_H

bool is_yes(char input);

#endif
