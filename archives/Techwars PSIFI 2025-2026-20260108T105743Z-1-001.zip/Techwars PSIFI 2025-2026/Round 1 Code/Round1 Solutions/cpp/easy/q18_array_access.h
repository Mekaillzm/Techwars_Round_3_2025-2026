#ifndef Q18_ARRAY_ACCESS_H
#define Q18_ARRAY_ACCESS_H

#include <vector>

int get_last_element(const std::vector<int>& arr);

#endif
