#include "q13_countdown.h"

std::vector<std::string> countdown(int start) {
    std::vector<std::string> result;
    int i = start;
    
    while (i > 0) {
        result.push_back(std::to_string(i));
        i--;  // Fixed: Added decrement
    }
    
    result.push_back("Liftoff!");
    return result;
}
