#include "q21_even_sum.h"

int sum_of_evens(int n) {
    int sum = 0;
    
    for (int i = 2; i <= n; i += 2) {
        sum += i;
    }
    
    return sum;
}
