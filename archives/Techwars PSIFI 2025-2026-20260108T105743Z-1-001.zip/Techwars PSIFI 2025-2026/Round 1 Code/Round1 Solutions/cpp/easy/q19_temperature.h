#ifndef Q19_TEMPERATURE_H
#define Q19_TEMPERATURE_H

double fahrenheit_to_celsius(double fahrenheit);
double celsius_to_fahrenheit(double celsius);

#endif
