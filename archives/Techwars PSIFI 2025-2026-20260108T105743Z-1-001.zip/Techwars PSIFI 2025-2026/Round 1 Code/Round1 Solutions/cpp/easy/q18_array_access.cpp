#include "q18_array_access.h"
#include <stdexcept>

int get_last_element(const std::vector<int>& arr) {
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    return arr[arr.size() - 1];  // Fixed: Correct index for last element
}
