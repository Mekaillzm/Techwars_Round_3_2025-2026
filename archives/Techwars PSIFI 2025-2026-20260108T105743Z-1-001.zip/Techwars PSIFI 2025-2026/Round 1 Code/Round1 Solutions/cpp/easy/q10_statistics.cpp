#include "q10_statistics.h"
#include <algorithm>
#include <stdexcept>

double calc_mean(const std::vector<int>& arr) {
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    double sum = 0.0;
    for (int x : arr) {
        sum += x;
    }
    return sum / arr.size();
}

double calc_median(std::vector<int> arr) {
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    std::sort(arr.begin(), arr.end());
    
    size_t n = arr.size();
    if (n % 2 == 0) {
        return (arr[n / 2 - 1] + arr[n / 2]) / 2.0;
    } else {
        return arr[n / 2];
    }
}

int calc_range(const std::vector<int>& arr) {
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    int minVal = arr[0];
    int maxVal = arr[0];
    
    for (int x : arr) {
        if (x < minVal) minVal = x;
        if (x > maxVal) maxVal = x;
    }
    
    return maxVal - minVal;
}
