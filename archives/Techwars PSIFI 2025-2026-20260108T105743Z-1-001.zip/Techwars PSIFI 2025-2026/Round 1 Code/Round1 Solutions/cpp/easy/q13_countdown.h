#ifndef Q13_COUNTDOWN_H
#define Q13_COUNTDOWN_H

#include <vector>
#include <string>

std::vector<std::string> countdown(int start);

#endif
