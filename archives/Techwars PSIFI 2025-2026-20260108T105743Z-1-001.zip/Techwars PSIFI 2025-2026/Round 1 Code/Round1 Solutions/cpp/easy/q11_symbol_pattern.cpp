#include "q11_symbol_pattern.h"

std::string generate_symbol_pattern(int a, int b) {
    int larger = (a > b) ? a : b;
    int smaller = (a < b) ? a : b;
    
    if (smaller == 0) return "";
    
    int limit = larger / smaller;
    
    std::string result = "";
    
    for (int i = 1; i <= limit; ++i) {
        if (i % 10 == 0) {
            result += '*';
        } else if (i % 5 == 0) {
            result += '#';
        } else {
            result += '-';
        }
    }
    
    return result;
}
