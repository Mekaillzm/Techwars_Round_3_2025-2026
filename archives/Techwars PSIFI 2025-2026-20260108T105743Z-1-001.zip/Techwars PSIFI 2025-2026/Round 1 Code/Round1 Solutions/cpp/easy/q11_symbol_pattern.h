#ifndef Q11_SYMBOL_PATTERN_H
#define Q11_SYMBOL_PATTERN_H

#include <string>

std::string generate_symbol_pattern(int a, int b);

#endif
