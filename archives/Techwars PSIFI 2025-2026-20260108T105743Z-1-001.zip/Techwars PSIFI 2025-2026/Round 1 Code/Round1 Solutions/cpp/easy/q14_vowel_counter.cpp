#include "q14_vowel_counter.h"
#include <cctype>

int count_vowels(const std::string& str) {
    int count = 0;
    
    for (char c : str) {
        char lower = std::tolower(c);
        if (lower == 'a' || lower == 'e' || lower == 'i' || 
            lower == 'o' || lower == 'u') {
            count++;
        }
    }
    
    return count;
}
