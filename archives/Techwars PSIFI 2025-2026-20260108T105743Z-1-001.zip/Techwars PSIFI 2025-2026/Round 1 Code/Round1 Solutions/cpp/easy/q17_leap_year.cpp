#include "q17_leap_year.h"

bool is_leap_year(int year) {
    // Divisible by 4, but if divisible by 100, must also be divisible by 400
    if (year % 400 == 0) return true;
    if (year % 100 == 0) return false;
    if (year % 4 == 0) return true;
    return false;
}
