#ifndef Q15_PERCENTAGE_H
#define Q15_PERCENTAGE_H

float calculate_percentage(int obtained, int total);

#endif
