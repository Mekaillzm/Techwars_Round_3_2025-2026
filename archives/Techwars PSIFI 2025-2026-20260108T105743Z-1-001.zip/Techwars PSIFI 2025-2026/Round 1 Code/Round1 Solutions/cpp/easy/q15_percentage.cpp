#include "q15_percentage.h"

float calculate_percentage(int obtained, int total) {
    // Fixed: Cast to float before division to avoid integer division
    float percentage = (static_cast<float>(obtained) / total) * 100;
    
    return percentage;
}
