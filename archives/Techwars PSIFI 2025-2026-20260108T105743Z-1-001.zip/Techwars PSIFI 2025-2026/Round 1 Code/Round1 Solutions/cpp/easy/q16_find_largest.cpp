#include "q16_find_largest.h"
#include <stdexcept>

int find_largest(const std::vector<int>& arr) {
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    int largest = arr[0];
    
    for (int x : arr) {
        if (x > largest) {
            largest = x;
        }
    }
    
    return largest;
}
