#include "q8_calculator.h"
#include <cmath>
#include <stdexcept>

int add(int a, int b) {
    return a + b;
}

int subtract(int a, int b) {
    return a - b;
}

int multiply(int a, int b) {
    return a * b;
}

int integer_divide(int a, int b) {
    if (b == 0) {
        throw std::runtime_error("division by zero");
    }
    return a / b;
}

double real_divide(double a, double b) {
    if (b == 0.0) {
        throw std::runtime_error("division by zero");
    }
    return a / b;
}

double power(int base, int exp) {
    return std::pow(base, exp);
}

int modulo(int a, int b) {
    if (b == 0) {
        throw std::runtime_error("modulo by zero");
    }
    return a % b;
}
