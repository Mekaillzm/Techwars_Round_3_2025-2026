#include "q5_oop.h"
#include <iostream>
#include <stdexcept>

BankAccount::BankAccount(double initial) : bal(initial) {}
BankAccount::~BankAccount() {}

void BankAccount::deposit(double amount) {
    if (amount < 0) return;
    bal += amount;
}

void BankAccount::withdraw(double amount) {
    if (amount < 0) return;
    if (amount > bal) {
        throw std::runtime_error("overdraft");
    }
    bal -= amount;
}

double BankAccount::balance() const { 
    return bal; 
}

SavingsAccount::SavingsAccount(double initial, double interest_rate) 
    : BankAccount(initial), rate(interest_rate) {}

void SavingsAccount::apply_interest() { 
    bal += bal * rate; 
}
