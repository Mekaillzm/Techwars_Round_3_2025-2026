#ifndef Q10_STATISTICS_H
#define Q10_STATISTICS_H

#include <vector>

double calc_mean(const std::vector<int>& arr);
double calc_median(std::vector<int> arr);
int calc_range(const std::vector<int>& arr);

#endif
