#ifndef Q14_VOWEL_COUNTER_H
#define Q14_VOWEL_COUNTER_H

#include <string>

int count_vowels(const std::string& str);

#endif
