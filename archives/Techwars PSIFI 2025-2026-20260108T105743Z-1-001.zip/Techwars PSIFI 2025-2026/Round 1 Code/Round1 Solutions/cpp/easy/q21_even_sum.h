#ifndef Q21_EVEN_SUM_H
#define Q21_EVEN_SUM_H

int sum_of_evens(int n);

#endif
