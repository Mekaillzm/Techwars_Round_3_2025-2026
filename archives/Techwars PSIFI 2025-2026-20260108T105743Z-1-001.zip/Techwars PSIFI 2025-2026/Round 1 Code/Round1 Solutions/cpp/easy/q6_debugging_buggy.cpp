#include "q6_debugging_buggy.h"
#include <limits>
#include <stdexcept>

int find_max(const std::vector<int>& arr) {
    if (arr.empty()) throw std::runtime_error("empty array");
    
    int m = arr[0];  // Fixed: Initialize with first element
    for (int x : arr) {
        if (x > m)  // Fixed: Compare correctly
            m = x;
    }
    return m;
}

double safe_divide(double a, double b) {
    if (b == 0.0) {
        throw std::runtime_error("division by zero");
    }
    return a / b;
}
