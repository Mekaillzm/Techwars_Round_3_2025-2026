#include "q7_caeser_cipher.h"

char shift_char(char c, int shift) {
    if (c >= 'a' && c <= 'z') {
        return char((c - 'a' + shift) % 26 + 'a');
    }
    if (c >= 'A' && c <= 'Z') {
        return char((c - 'A' + shift) % 26 + 'A');
    }
    return c;
}

std::vector<std::string> all_caesar_shifts(const std::string& s) {
    std::vector<std::string> out;
    out.reserve(26);
    
    for (int sh = 0; sh < 26; ++sh) {
        std::string cur;
        for (char ch : s) {
            cur.push_back(shift_char(ch, sh));
        }
        out.push_back(cur);
    }
    return out;
}
