#include "q4_procedural.h"
#include <stdexcept>
#include <algorithm>

std::vector<std::vector<int>> transpose(const std::vector<std::vector<int>>& matrix) {
    if (matrix.empty()) return {};

    size_t rows = matrix.size();
    size_t cols = matrix[0].size();

    std::vector<std::vector<int>> out(cols, std::vector<int>(rows));

    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            out[j][i] = matrix[i][j];
        }
    }
    return out;
}

std::vector<std::vector<int>> rotate_right(const std::vector<std::vector<int>>& matrix) {
    auto t = transpose(matrix);
    for (auto& row : t) {
        std::reverse(row.begin(), row.end());
    }
    return t;
}
