#ifndef Q29_DEFAULT_ARG_BUG_H
#define Q29_DEFAULT_ARG_BUG_H

#include <vector>
#include <string>

std::vector<std::string> add_student(const std::string& name, std::vector<std::string> list = {});
std::vector<std::string> add_student_fixed(const std::string& name, std::vector<std::string>* list = nullptr);

#endif
