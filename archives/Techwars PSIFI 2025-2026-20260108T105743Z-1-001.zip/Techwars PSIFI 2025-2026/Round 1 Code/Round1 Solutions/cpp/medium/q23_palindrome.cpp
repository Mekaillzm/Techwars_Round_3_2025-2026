#include "q23_palindrome.h"
#include <cctype>

bool is_palindrome(const std::string& str) {
    // Filter to get only alphanumeric characters, converted to lowercase
    std::string filtered;
    for (char c : str) {
        if (std::isalnum(c)) {
            filtered += std::tolower(c);
        }
    }
    
    // Check palindrome using two pointers
    int left = 0;
    int right = filtered.size() - 1;
    
    while (left < right) {
        if (filtered[left] != filtered[right]) {
            return false;
        }
        left++;
        right--;
    }
    
    return true;
}
