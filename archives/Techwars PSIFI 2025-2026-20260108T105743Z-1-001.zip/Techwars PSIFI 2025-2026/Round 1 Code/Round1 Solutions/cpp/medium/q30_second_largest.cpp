#include "q30_second_largest.h"
#include <stdexcept>
#include <limits>

int find_second_largest(const std::vector<int>& arr) {
    if (arr.size() < 2) {
        throw std::runtime_error("need at least 2 elements");
    }
    
    int largest = std::numeric_limits<int>::min();
    int second = std::numeric_limits<int>::min();
    
    for (int x : arr) {
        if (x > largest) {
            second = largest;
            largest = x;
        } else if (x > second && x != largest) {
            second = x;
        }
    }
    
    if (second == std::numeric_limits<int>::min()) {
        throw std::runtime_error("need at least 2 distinct elements");
    }
    
    return second;
}
