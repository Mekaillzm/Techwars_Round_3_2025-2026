#ifndef Q26_STUDENT_CLASS_H
#define Q26_STUDENT_CLASS_H

#include <string>

class Student {
public:
    Student(const std::string& name, int id, double gpa);
    
    std::string getName() const;
    int getId() const;
    double getGpa() const;
    bool isHonors() const;

private:
    std::string name_;
    int id_;
    double gpa_;
};

#endif
