#include "q2_linkedlist.h"
#include <stdexcept>

LinkedList::LinkedList() : head(nullptr) {}

LinkedList::~LinkedList() {
    Node* cur = head;
    while (cur) {
        Node* nxt = cur->next;
        delete cur;
        cur = nxt;
    }
    head = nullptr;
}

void LinkedList::insert_at_head(int value) {
    Node* n = new Node(value);
    n->next = head;
    head = n;
}

void LinkedList::insert_at_tail(int value) {
    Node* n = new Node(value);
    if (!head) {
        head = n;
        return;
    }
    Node* cur = head;
    while (cur->next) cur = cur->next;
    cur->next = n;
}

bool LinkedList::delete_value(int value) {
    Node* cur = head;
    Node* prev = nullptr;
    while (cur) {
        if (cur->value == value) {
            if (prev) prev->next = cur->next;
            else head = cur->next;
            delete cur;
            return true;
        }
        prev = cur;
        cur = cur->next;
    }
    return false;
}

std::vector<int> LinkedList::to_vector() const {
    std::vector<int> out;
    Node* cur = head;
    while (cur) {
        out.push_back(cur->value);
        cur = cur->next;
    }
    return out;
}
