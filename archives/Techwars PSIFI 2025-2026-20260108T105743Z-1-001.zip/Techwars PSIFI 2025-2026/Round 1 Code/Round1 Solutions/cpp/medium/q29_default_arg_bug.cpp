#include "q29_default_arg_bug.h"

std::vector<std::string> add_student(const std::string& name, std::vector<std::string> list) {
    list.push_back(name);
    return list;
}

std::vector<std::string> add_student_fixed(const std::string& name, std::vector<std::string>* list) {
    std::vector<std::string> result;
    if (list != nullptr) {
        result = *list;
    }
    result.push_back(name);
    return result;
}
