#ifndef Q30_SECOND_LARGEST_H
#define Q30_SECOND_LARGEST_H

#include <vector>

int find_second_largest(const std::vector<int>& arr);

#endif
