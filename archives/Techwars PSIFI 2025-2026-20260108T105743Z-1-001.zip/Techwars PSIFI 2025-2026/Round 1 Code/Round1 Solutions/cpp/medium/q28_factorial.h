#ifndef Q28_FACTORIAL_H
#define Q28_FACTORIAL_H

long long factorial(int n);

#endif
