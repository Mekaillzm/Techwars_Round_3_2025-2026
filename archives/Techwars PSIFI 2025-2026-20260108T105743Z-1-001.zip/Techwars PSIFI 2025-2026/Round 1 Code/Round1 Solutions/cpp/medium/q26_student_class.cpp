#include "q26_student_class.h"

Student::Student(const std::string& name, int id, double gpa)
    : name_(name), id_(id), gpa_(gpa) {}

std::string Student::getName() const {
    return name_;
}

int Student::getId() const {
    return id_;
}

double Student::getGpa() const {
    return gpa_;
}

bool Student::isHonors() const {
    return gpa_ > 3.5;
}
