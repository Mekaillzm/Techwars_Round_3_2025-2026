#ifndef Q4_PROCEDURAL_H
#define Q4_PROCEDURAL_H

#include <vector>

std::vector<std::vector<int>> transpose(const std::vector<std::vector<int>>& matrix);
std::vector<std::vector<int>> rotate_right(const std::vector<std::vector<int>>& matrix);

#endif
