#ifndef Q25_MATRIX_ADD_H
#define Q25_MATRIX_ADD_H

#include <vector>

std::vector<std::vector<int>> matrix_add(
    const std::vector<std::vector<int>>& a,
    const std::vector<std::vector<int>>& b);

#endif
