#ifndef Q23_PALINDROME_H
#define Q23_PALINDROME_H

#include <string>

bool is_palindrome(const std::string& str);

#endif
