#ifndef Q24_STRING_CONCAT_H
#define Q24_STRING_CONCAT_H

#include <string>

std::string create_introduction(const std::string& name, int age);

#endif
