#include "q25_matrix_add.h"

std::vector<std::vector<int>> matrix_add(
    const std::vector<std::vector<int>>& a,
    const std::vector<std::vector<int>>& b) {
    
    if (a.empty()) return {};
    
    size_t rows = a.size();
    size_t cols = a[0].size();
    
    std::vector<std::vector<int>> result(rows, std::vector<int>(cols));
    
    for (size_t i = 0; i < rows; ++i) {
        for (size_t j = 0; j < cols; ++j) {
            result[i][j] = a[i][j] + b[i][j];
        }
    }
    
    return result;
}
