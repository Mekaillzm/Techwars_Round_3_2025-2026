#include "q24_string_concat.h"

std::string create_introduction(const std::string& name, int age) {
    // Fixed: Properly convert age to string before concatenation
    return "My name is " + name + " and I am " + std::to_string(age) + " years old.";
}
