#ifndef Q7_CAESER_CIPHER_H
#define Q7_CAESER_CIPHER_H

#include <string>
#include <vector>

std::vector<std::string> all_caesar_shifts(const std::string& s);

#endif
