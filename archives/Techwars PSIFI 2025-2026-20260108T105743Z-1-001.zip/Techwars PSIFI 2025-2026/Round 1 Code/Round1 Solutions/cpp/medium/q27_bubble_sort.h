#ifndef Q27_BUBBLE_SORT_H
#define Q27_BUBBLE_SORT_H

#include <vector>

void bubble_sort(std::vector<int>& arr);

#endif
