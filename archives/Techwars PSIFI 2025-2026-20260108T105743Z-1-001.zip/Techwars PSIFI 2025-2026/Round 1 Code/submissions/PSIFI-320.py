"""
Q2 (Python): Singly linked list implementation.

Contract:
- Implement `Node` dataclass with `value` and `next`.
- Implement `LinkedList` with methods: `insert_at_head(value)`, `insert_at_tail(value)`, `delete_value(value)`, `to_list()`.
- `delete_value` deletes the first occurrence and returns True if deleted, False otherwise.
"""

from dataclasses import dataclass
from typing import Optional, List


@dataclass
class Node:
    value: int
    next: Optional['Node'] = None


class LinkedList:
    def __init__(self):
        self.head: Optional[Node] = None

    def insert_at_head(self, value: int) -> None:
        
        return
    
    def insert_at_tail(self, value: int) -> None:
        
        return 

    def delete_value(self, value: int) -> bool:
        
        return

    def to_list(self) -> List[int]:
        
        return
