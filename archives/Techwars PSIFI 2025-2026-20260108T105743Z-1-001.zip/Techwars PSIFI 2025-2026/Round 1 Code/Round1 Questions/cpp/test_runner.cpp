#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>

// Easy questions (weightage: 3)
#include "easy/q1_pointers.h"
#include "easy/q5_oop.h"
#include "easy/q6_debugging_buggy.h"
#include "easy/q8_calculator.h"
#include "easy/q10_statistics.h"
#include "easy/q11_symbol_pattern.h"
#include "easy/q12_techwars_loop.h"
#include "easy/q13_countdown.h"
#include "easy/q14_vowel_counter.h"
#include "easy/q15_percentage.h"
#include "easy/q16_find_largest.h"
#include "easy/q17_leap_year.h"
#include "easy/q18_array_access.h"
#include "easy/q19_temperature.h"
#include "easy/q20_scope_bug.h"
#include "easy/q21_even_sum.h"
#include "easy/q22_logic_bug.h"

// Medium questions (weightage: 7)
#include "medium/q2_linkedlist.h"
#include "medium/q4_procedural.h"
#include "medium/q7_caeser_cipher.h"
#include "medium/q23_palindrome.h"
#include "medium/q24_string_concat.h"
#include "medium/q25_matrix_add.h"
#include "medium/q26_student_class.h"
#include "medium/q27_bubble_sort.h"
#include "medium/q28_factorial.h"
#include "medium/q29_default_arg_bug.h"
#include "medium/q30_second_largest.h"

// Hard questions (weightage: 12)
#include "hard/q3_stack_queue.h"
#include "hard/q9_binary_addition.h"
#include "hard/q31_reverse_list.h"
#include "hard/q32_binary_search.h"
#include "hard/q33_copy_constructor.h"

static const char* GREEN = "\033[32m";
static const char* RED = "\033[31m";
static const char* YELLOW = "\033[33m";
static const char* RESET = "\033[0m";

// Weightage constants
static const int EASY_WEIGHT = 3;
static const int MEDIUM_WEIGHT = 7;
static const int HARD_WEIGHT = 12;

void print_header(const std::string &title, const std::string &difficulty, int weight) {
    std::cout << "========================================\n";
    std::cout << title << " [" << difficulty << " - " << weight << " pts] — detailed breakdown:\n";
}

void print_footer(bool passed, int weight) {
    std::cout << "----------------------------------------\n";
    if (passed) std::cout << GREEN << "TOTAL: PASS (" << weight << "/" << weight << " pts)" << RESET << "\n";
    else std::cout << RED << "TOTAL: FAIL (0/" << weight << " pts)" << RESET << "\n";
    std::cout << "========================================\n";
}

std::string ok_flag(bool cond) {
    return cond ? std::string(GREEN) + "OK" + RESET : std::string(RED) + "FAIL" + RESET;
}

// ==================== EASY QUESTIONS (3 pts each) ====================

int run_q1() {
    int swap_pts = 0, offset_val_pts = 0, offset_bounds_pts = 0;
    const int swap_max = 1, offset_val_max = 1, offset_bounds_max = 1;
    try {
        int arr[] = {10,20,30,40};
        swap_by_ptrs(&arr[1], &arr[3]);
        if (arr[0]==10 && arr[1]==40 && arr[2]==30 && arr[3]==20) swap_pts = swap_max;

        int v = get_offset_value(arr, 0, 2, 4);
        if (v == 30) offset_val_pts = offset_val_max;
        int v2 = get_offset_value(arr, 2, 2, 4);
        if (v2 != 0) offset_bounds_pts = offset_bounds_max;
    } catch (...) {}

    int total = swap_max + offset_val_max + offset_bounds_max;
    int score = swap_pts + offset_val_pts + offset_bounds_pts;
    bool passed = (score == total);

    print_header("q1_pointers", "EASY", EASY_WEIGHT);
    std::cout << "  swap_by_ptrs              : " << ok_flag(swap_pts==swap_max) << "\n";
    std::cout << "  get_offset_value (value)  : " << ok_flag(offset_val_pts==offset_val_max) << "\n";
    std::cout << "  get_offset_value (bounds) : " << ok_flag(offset_bounds_pts==offset_bounds_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q5() {
    int wd_ok_pts = 0, wd_fail_pts = 0, inherit_pts = 0;
    const int wd_ok_max = 1, wd_fail_max = 1, inherit_max = 1;
    try {
        BankAccount ba(100.0);
        ba.deposit(50.0);
        ba.withdraw(30.0);
        if (std::abs(ba.balance() - 120.0) < 0.01) wd_ok_pts = wd_ok_max;
        try { ba.withdraw(500.0); } catch (...) { wd_fail_pts = wd_fail_max; }

        SavingsAccount sa(200.0, 0.1);
        sa.apply_interest();
        if (std::abs(sa.balance() - 220.0) < 0.01) inherit_pts = inherit_max;
    } catch (...) {}

    int total = wd_ok_max + wd_fail_max + inherit_max;
    int score = wd_ok_pts + wd_fail_pts + inherit_pts;
    bool passed = (score == total);

    print_header("q5_oop", "EASY", EASY_WEIGHT);
    std::cout << "  withdraw success  : " << ok_flag(wd_ok_pts==wd_ok_max) << "\n";
    std::cout << "  withdraw fail     : " << ok_flag(wd_fail_pts==wd_fail_max) << "\n";
    std::cout << "  inheritance       : " << ok_flag(inherit_pts==inherit_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q6() {
    int max_pts = 0, div_ok_pts = 0, div_zero_pts = 0;
    const int max_max = 1, div_ok_max = 1, div_zero_max = 1;
    try {
        std::vector<int> nums = {3, 7, 2, 9, 4};
        if (find_max(nums) == 9) max_pts = max_max;
        double res = safe_divide(10.0, 2.0);
        if (std::abs(res - 5.0) < 0.01) div_ok_pts = div_ok_max;
        try { safe_divide(5.0, 0.0); } catch (...) { div_zero_pts = div_zero_max; }
    } catch (...) {}

    int total = max_max + div_ok_max + div_zero_max;
    int score = max_pts + div_ok_pts + div_zero_pts;
    bool passed = (score == total);

    print_header("q6_debugging_buggy", "EASY", EASY_WEIGHT);
    std::cout << "  find_max          : " << ok_flag(max_pts==max_max) << "\n";
    std::cout << "  safe_divide ok    : " << ok_flag(div_ok_pts==div_ok_max) << "\n";
    std::cout << "  safe_divide /0    : " << ok_flag(div_zero_pts==div_zero_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q8() {
    int add_pts=0, sub_pts=0, mul_pts=0, idiv_pts=0, rdiv_pts=0, pow_pts=0, mod_pts=0;
    const int add_max=1, sub_max=1, mul_max=1, idiv_max=1, rdiv_max=1, pow_max=1, mod_max=1;
    try {
        if (add(5, 3) == 8) add_pts = add_max;
        if (subtract(10, 4) == 6) sub_pts = sub_max;
        if (multiply(3, 7) == 21) mul_pts = mul_max;
        if (integer_divide(17, 5) == 3) idiv_pts = idiv_max;
        if (std::abs(real_divide(7.0, 2.0) - 3.5) < 0.01) rdiv_pts = rdiv_max;
        if (power(2, 10) == 1024) pow_pts = pow_max;
        if (modulo(17, 5) == 2) mod_pts = mod_max;
    } catch (...) {}

    int total = add_max+sub_max+mul_max+idiv_max+rdiv_max+pow_max+mod_max;
    int score = add_pts+sub_pts+mul_pts+idiv_pts+rdiv_pts+pow_pts+mod_pts;
    bool passed = (score == total);

    print_header("q8_calculator", "EASY", EASY_WEIGHT);
    std::cout << "  add           : " << ok_flag(add_pts==add_max) << "\n";
    std::cout << "  subtract      : " << ok_flag(sub_pts==sub_max) << "\n";
    std::cout << "  multiply      : " << ok_flag(mul_pts==mul_max) << "\n";
    std::cout << "  integer_divide: " << ok_flag(idiv_pts==idiv_max) << "\n";
    std::cout << "  real_divide   : " << ok_flag(rdiv_pts==rdiv_max) << "\n";
    std::cout << "  power         : " << ok_flag(pow_pts==pow_max) << "\n";
    std::cout << "  modulo        : " << ok_flag(mod_pts==mod_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q10() {
    int mean_pts=0, median_odd_pts=0, median_even_pts=0, range_pts=0;
    const int mean_max=1, median_odd_max=1, median_even_max=1, range_max=1;
    try {
        std::vector<int> v1 = {1,2,3,4,5};
        if (std::abs(calc_mean(v1) - 3.0) < 0.01) mean_pts = mean_max;
        if (std::abs(calc_median(v1) - 3.0) < 0.01) median_odd_pts = median_odd_max;
        std::vector<int> v2 = {1,2,3,4};
        if (std::abs(calc_median(v2) - 2.5) < 0.01) median_even_pts = median_even_max;
        if (calc_range(v1) == 4) range_pts = range_max;
    } catch (...) {}

    int total = mean_max+median_odd_max+median_even_max+range_max;
    int score = mean_pts+median_odd_pts+median_even_pts+range_pts;
    bool passed = (score == total);

    print_header("q10_statistics", "EASY", EASY_WEIGHT);
    std::cout << "  mean          : " << ok_flag(mean_pts==mean_max) << "\n";
    std::cout << "  median (odd)  : " << ok_flag(median_odd_pts==median_odd_max) << "\n";
    std::cout << "  median (even) : " << ok_flag(median_even_pts==median_even_max) << "\n";
    std::cout << "  range         : " << ok_flag(range_pts==range_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q11() {
    int simple_pts=0, mult5_pts=0, mult10_pts=0;
    const int simple_max=1, mult5_max=1, mult10_max=1;
    try {
        // generate_symbol_pattern(a, b) computes limit = larger/smaller, then for 1..limit:
        // '*' for multiples of 10, '#' for multiples of 5 (not 10), '-' otherwise
        std::string s3 = generate_symbol_pattern(3, 1);  // limit=3: 1='-', 2='-', 3='-'
        if (s3 == "---") simple_pts = simple_max;
        std::string s5 = generate_symbol_pattern(10, 2);  // limit=5: positions 1-4 are '-', position 5 is '#'
        if (s5.length() == 5 && s5[4] == '#') mult5_pts = mult5_max;
        std::string s10 = generate_symbol_pattern(10, 1);  // limit=10: position 10 is '*'
        if (s10.length() == 10 && s10[9] == '*') mult10_pts = mult10_max;
    } catch (...) {}

    int total = simple_max+mult5_max+mult10_max;
    int score = simple_pts+mult5_pts+mult10_pts;
    bool passed = (score == total);

    print_header("q11_symbol_pattern", "EASY", EASY_WEIGHT);
    std::cout << "  simple pattern    : " << ok_flag(simple_pts==simple_max) << "\n";
    std::cout << "  mult of 5 (#)     : " << ok_flag(mult5_pts==mult5_max) << "\n";
    std::cout << "  mult of 10 (*)    : " << ok_flag(mult10_pts==mult10_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q12() {
    int seq15_pts=0, tech_pts=0, wars_pts=0, techwars_pts=0;
    const int seq15_max=1, tech_max=1, wars_max=1, techwars_max=1;
    try {
        auto seq = techwars_sequence(15);
        if (seq.size() == 15) seq15_pts = seq15_max;
        if (seq.size() >= 3 && seq[2] == "Tech") tech_pts = tech_max;
        if (seq.size() >= 5 && seq[4] == "Wars") wars_pts = wars_max;
        if (seq.size() >= 15 && seq[14] == "TechWars") techwars_pts = techwars_max;
    } catch (...) {}

    int total = seq15_max+tech_max+wars_max+techwars_max;
    int score = seq15_pts+tech_pts+wars_pts+techwars_pts;
    bool passed = (score == total);

    print_header("q12_techwars_loop", "EASY", EASY_WEIGHT);
    std::cout << "  sequence length   : " << ok_flag(seq15_pts==seq15_max) << "\n";
    std::cout << "  Tech (mult of 3)  : " << ok_flag(tech_pts==tech_max) << "\n";
    std::cout << "  Wars (mult of 5)  : " << ok_flag(wars_pts==wars_max) << "\n";
    std::cout << "  TechWars (mult 15): " << ok_flag(techwars_pts==techwars_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q13() {
    int len_pts=0, first_pts=0, last_pts=0, liftoff_pts=0;
    const int len_max=1, first_max=1, last_max=1, liftoff_max=1;
    try {
        auto seq = countdown(5);
        if (seq.size() == 6) len_pts = len_max;
        if (seq.size() >= 1 && seq[0] == "5") first_pts = first_max;
        if (seq.size() >= 5 && seq[4] == "1") last_pts = last_max;
        if (seq.size() >= 6 && seq[5] == "Liftoff!") liftoff_pts = liftoff_max;
    } catch (...) {}

    int total = len_max+first_max+last_max+liftoff_max;
    int score = len_pts+first_pts+last_pts+liftoff_pts;
    bool passed = (score == total);

    print_header("q13_countdown", "EASY", EASY_WEIGHT);
    std::cout << "  sequence length   : " << ok_flag(len_pts==len_max) << "\n";
    std::cout << "  first element (5) : " << ok_flag(first_pts==first_max) << "\n";
    std::cout << "  last number (1)   : " << ok_flag(last_pts==last_max) << "\n";
    std::cout << "  Liftoff! at end   : " << ok_flag(liftoff_pts==liftoff_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q14() {
    int simple_pts=0, mixed_pts=0, empty_pts=0;
    const int simple_max=1, mixed_max=1, empty_max=1;
    try {
        if (count_vowels("hello") == 2) simple_pts = simple_max;
        if (count_vowels("AEIOUaeiou") == 10) mixed_pts = mixed_max;
        if (count_vowels("xyz") == 0) empty_pts = empty_max;
    } catch (...) {}

    int total = simple_max+mixed_max+empty_max;
    int score = simple_pts+mixed_pts+empty_pts;
    bool passed = (score == total);

    print_header("q14_vowel_counter", "EASY", EASY_WEIGHT);
    std::cout << "  simple string     : " << ok_flag(simple_pts==simple_max) << "\n";
    std::cout << "  mixed case vowels : " << ok_flag(mixed_pts==mixed_max) << "\n";
    std::cout << "  no vowels         : " << ok_flag(empty_pts==empty_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q15() {
    int basic_pts=0, full_pts=0;
    const int basic_max=1, full_max=1;
    try {
        double p1 = calculate_percentage(45, 50);
        if (std::abs(p1 - 90.0) < 0.1) basic_pts = basic_max;
        double p2 = calculate_percentage(1, 3);
        if (std::abs(p2 - 33.33) < 0.1) full_pts = full_max;
    } catch (...) {}

    int total = basic_max+full_max;
    int score = basic_pts+full_pts;
    bool passed = (score == total);

    print_header("q15_percentage", "EASY", EASY_WEIGHT);
    std::cout << "  basic percentage  : " << ok_flag(basic_pts==basic_max) << "\n";
    std::cout << "  decimal percentage: " << ok_flag(full_pts==full_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q16() {
    int pos_pts=0, neg_pts=0, single_pts=0;
    const int pos_max=1, neg_max=1, single_max=1;
    try {
        std::vector<int> v1 = {1, 5, 3, 9, 2};
        if (find_largest(v1) == 9) pos_pts = pos_max;
        std::vector<int> v2 = {-10, -5, -20};
        if (find_largest(v2) == -5) neg_pts = neg_max;
        std::vector<int> v3 = {42};
        if (find_largest(v3) == 42) single_pts = single_max;
    } catch (...) {}

    int total = pos_max+neg_max+single_max;
    int score = pos_pts+neg_pts+single_pts;
    bool passed = (score == total);

    print_header("q16_find_largest", "EASY", EASY_WEIGHT);
    std::cout << "  positive numbers  : " << ok_flag(pos_pts==pos_max) << "\n";
    std::cout << "  negative numbers  : " << ok_flag(neg_pts==neg_max) << "\n";
    std::cout << "  single element    : " << ok_flag(single_pts==single_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q17() {
    int leap_pts=0, century_pts=0, quad_century_pts=0, non_leap_pts=0;
    const int leap_max=1, century_max=1, quad_century_max=1, non_leap_max=1;
    try {
        if (is_leap_year(2024)) leap_pts = leap_max;
        if (!is_leap_year(1900)) century_pts = century_max;
        if (is_leap_year(2000)) quad_century_pts = quad_century_max;
        if (!is_leap_year(2023)) non_leap_pts = non_leap_max;
    } catch (...) {}

    int total = leap_max+century_max+quad_century_max+non_leap_max;
    int score = leap_pts+century_pts+quad_century_pts+non_leap_pts;
    bool passed = (score == total);

    print_header("q17_leap_year", "EASY", EASY_WEIGHT);
    std::cout << "  regular leap year : " << ok_flag(leap_pts==leap_max) << "\n";
    std::cout << "  century non-leap  : " << ok_flag(century_pts==century_max) << "\n";
    std::cout << "  400-year leap     : " << ok_flag(quad_century_pts==quad_century_max) << "\n";
    std::cout << "  regular non-leap  : " << ok_flag(non_leap_pts==non_leap_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q18() {
    int correct_pts=0;
    const int correct_max=1;
    try {
        std::vector<int> arr = {10, 20, 30, 40, 50};
        if (get_last_element(arr) == 50) correct_pts = correct_max;
    } catch (...) {}

    int total = correct_max;
    int score = correct_pts;
    bool passed = (score == total);

    print_header("q18_array_access", "EASY", EASY_WEIGHT);
    std::cout << "  get last element  : " << ok_flag(correct_pts==correct_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q19() {
    int f_to_c_pts=0, c_to_f_pts=0, freeze_pts=0;
    const int f_to_c_max=1, c_to_f_max=1, freeze_max=1;
    try {
        if (std::abs(fahrenheit_to_celsius(212.0) - 100.0) < 0.1) f_to_c_pts = f_to_c_max;
        if (std::abs(celsius_to_fahrenheit(100.0) - 212.0) < 0.1) c_to_f_pts = c_to_f_max;
        if (std::abs(fahrenheit_to_celsius(32.0) - 0.0) < 0.1) freeze_pts = freeze_max;
    } catch (...) {}

    int total = f_to_c_max+c_to_f_max+freeze_max;
    int score = f_to_c_pts+c_to_f_pts+freeze_pts;
    bool passed = (score == total);

    print_header("q19_temperature", "EASY", EASY_WEIGHT);
    std::cout << "  F to C (boiling)  : " << ok_flag(f_to_c_pts==f_to_c_max) << "\n";
    std::cout << "  C to F (boiling)  : " << ok_flag(c_to_f_pts==c_to_f_max) << "\n";
    std::cout << "  F to C (freezing) : " << ok_flag(freeze_pts==freeze_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q20() {
    int calc_pts=0;
    const int calc_max=1;
    try {
        if (calculate_total(false, 100, 50) == 0) calc_pts = calc_max;
    } catch (...) {}

    int total = calc_max;
    int score = calc_pts;
    bool passed = (score == total);

    print_header("q20_scope_bug", "EASY", EASY_WEIGHT);
    std::cout << "  calculate total   : " << ok_flag(calc_pts==calc_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q21() {
    int small_pts=0, ten_pts=0, odd_pts=0;
    const int small_max=1, ten_max=1, odd_max=1;
    try {
        if (sum_of_evens(6) == 12) small_pts = small_max;
        if (sum_of_evens(10) == 30) ten_pts = ten_max;
        if (sum_of_evens(7) == 12) odd_pts = odd_max;
    } catch (...) {}

    int total = small_max+ten_max+odd_max;
    int score = small_pts+ten_pts+odd_pts;
    bool passed = (score == total);

    print_header("q21_even_sum", "EASY", EASY_WEIGHT);
    std::cout << "  sum to 6          : " << ok_flag(small_pts==small_max) << "\n";
    std::cout << "  sum to 10         : " << ok_flag(ten_pts==ten_max) << "\n";
    std::cout << "  sum to 7 (odd n)  : " << ok_flag(odd_pts==odd_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

int run_q22() {
    int lower_pts=0, upper_pts=0, other_pts=0;
    const int lower_max=1, upper_max=1, other_max=1;
    try {
        if (is_yes('y')) lower_pts = lower_max;
        if (is_yes('Y')) upper_pts = upper_max;
        if (!is_yes('n')) other_pts = other_max;
    } catch (...) {}

    int total = lower_max+upper_max+other_max;
    int score = lower_pts+upper_pts+other_pts;
    bool passed = (score == total);

    print_header("q22_logic_bug", "EASY", EASY_WEIGHT);
    std::cout << "  lowercase 'y'     : " << ok_flag(lower_pts==lower_max) << "\n";
    std::cout << "  uppercase 'Y'     : " << ok_flag(upper_pts==upper_max) << "\n";
    std::cout << "  other char 'n'    : " << ok_flag(other_pts==other_max) << "\n";
    print_footer(passed, EASY_WEIGHT);
    return passed ? EASY_WEIGHT : 0;
}

// ==================== MEDIUM QUESTIONS (7 pts each) ====================

int run_q2() {
    int head_pts=0, tail_pts=0, tovec_pts=0, del_pts=0;
    const int head_max=1, tail_max=1, tovec_max=1, del_max=1;
    try {
        LinkedList ll;
        ll.insert_at_head(10);
        ll.insert_at_head(20);
        head_pts = head_max;

        ll.insert_at_tail(5);
        tail_pts = tail_max;

        auto v = ll.to_vector();
        std::vector<int> expected = {20,10,5};
        if (v == expected) tovec_pts = tovec_max;

        ll.delete_value(10);
        auto v2 = ll.to_vector();
        std::vector<int> expected2 = {20,5};
        if (v2 == expected2) del_pts = del_max;
    } catch (...) {}

    int total = head_max+tail_max+tovec_max+del_max;
    int score = head_pts+tail_pts+tovec_pts+del_pts;
    bool passed = (score == total);

    print_header("q2_linkedlist", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  insert_at_head    : " << ok_flag(head_pts==head_max) << "\n";
    std::cout << "  insert_at_tail    : " << ok_flag(tail_pts==tail_max) << "\n";
    std::cout << "  to_vector         : " << ok_flag(tovec_pts==tovec_max) << "\n";
    std::cout << "  delete_value      : " << ok_flag(del_pts==del_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q4() {
    int trans_pts=0, rotate_pts=0;
    const int trans_max=1, rotate_max=1;
    try {
        std::vector<std::vector<int>> mat = {{1,2,3},{4,5,6}};
        auto t = transpose(mat);
        std::vector<std::vector<int>> expected_t = {{1,4},{2,5},{3,6}};
        if (t == expected_t) trans_pts = trans_max;

        std::vector<std::vector<int>> sq = {{1,2},{3,4}};
        auto r = rotate_right(sq);
        std::vector<std::vector<int>> expected_r = {{3,1},{4,2}};
        if (r == expected_r) rotate_pts = rotate_max;
    } catch (...) {}

    int total = trans_max+rotate_max;
    int score = trans_pts+rotate_pts;
    bool passed = (score == total);

    print_header("q4_procedural", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  transpose         : " << ok_flag(trans_pts==trans_max) << "\n";
    std::cout << "  rotate_right      : " << ok_flag(rotate_pts==rotate_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q7() {
    int has_orig_pts=0, shift13_pts=0;
    const int has_orig_max=1, shift13_max=1;
    try {
        std::string plain = "abc";
        auto shifts = all_caesar_shifts(plain);
        if (shifts.size() == 26 && shifts[0] == plain) has_orig_pts = has_orig_max;
        if (shifts.size() >= 14 && shifts[13] == "nop") shift13_pts = shift13_max;
    } catch (...) {}

    int total = has_orig_max+shift13_max;
    int score = has_orig_pts+shift13_pts;
    bool passed = (score == total);

    print_header("q7_caeser_cipher", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  has original      : " << ok_flag(has_orig_pts==has_orig_max) << "\n";
    std::cout << "  shift 13 (ROT13)  : " << ok_flag(shift13_pts==shift13_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q23() {
    int simple_pts=0, phrase_pts=0, non_pts=0;
    const int simple_max=1, phrase_max=1, non_max=1;
    try {
        if (is_palindrome("racecar")) simple_pts = simple_max;
        if (is_palindrome("A man a plan a canal Panama")) phrase_pts = phrase_max;
        if (!is_palindrome("hello")) non_pts = non_max;
    } catch (...) {}

    int total = simple_max+phrase_max+non_max;
    int score = simple_pts+phrase_pts+non_pts;
    bool passed = (score == total);

    print_header("q23_palindrome", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  simple palindrome : " << ok_flag(simple_pts==simple_max) << "\n";
    std::cout << "  phrase palindrome : " << ok_flag(phrase_pts==phrase_max) << "\n";
    std::cout << "  non-palindrome    : " << ok_flag(non_pts==non_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q24() {
    int intro_pts=0;
    const int intro_max=1;
    try {
        std::string result = create_introduction("Ahmed", 17);
        if (result == "My name is Ahmed and I am 17 years old.") intro_pts = intro_max;
    } catch (...) {}

    int total = intro_max;
    int score = intro_pts;
    bool passed = (score == total);

    print_header("q24_string_concat", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  create intro      : " << ok_flag(intro_pts==intro_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q25() {
    int add_2x2_pts=0, add_3x3_pts=0;
    const int add_2x2_max=1, add_3x3_max=1;
    try {
        std::vector<std::vector<int>> a = {{1,2},{3,4}};
        std::vector<std::vector<int>> b = {{5,6},{7,8}};
        std::vector<std::vector<int>> expected = {{6,8},{10,12}};
        if (matrix_add(a, b) == expected) add_2x2_pts = add_2x2_max;

        std::vector<std::vector<int>> c = {{1,1,1},{2,2,2},{3,3,3}};
        std::vector<std::vector<int>> d = {{1,0,0},{0,1,0},{0,0,1}};
        std::vector<std::vector<int>> exp2 = {{2,1,1},{2,3,2},{3,3,4}};
        if (matrix_add(c, d) == exp2) add_3x3_pts = add_3x3_max;
    } catch (...) {}

    int total = add_2x2_max+add_3x3_max;
    int score = add_2x2_pts+add_3x3_pts;
    bool passed = (score == total);

    print_header("q25_matrix_add", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  2x2 matrix add    : " << ok_flag(add_2x2_pts==add_2x2_max) << "\n";
    std::cout << "  3x3 matrix add    : " << ok_flag(add_3x3_pts==add_3x3_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q26() {
    int name_pts=0, gpa_pts=0, honors_yes_pts=0, honors_no_pts=0;
    const int name_max=1, gpa_max=1, honors_yes_max=1, honors_no_max=1;
    try {
        Student s1("Ali", 123, 3.8);
        if (s1.getName() == "Ali") name_pts = name_max;
        if (std::abs(s1.getGpa() - 3.8) < 0.01) gpa_pts = gpa_max;
        if (s1.isHonors()) honors_yes_pts = honors_yes_max;

        Student s2("Bob", 456, 3.0);
        if (!s2.isHonors()) honors_no_pts = honors_no_max;
    } catch (...) {}

    int total = name_max+gpa_max+honors_yes_max+honors_no_max;
    int score = name_pts+gpa_pts+honors_yes_pts+honors_no_pts;
    bool passed = (score == total);

    print_header("q26_student_class", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  get name          : " << ok_flag(name_pts==name_max) << "\n";
    std::cout << "  get gpa           : " << ok_flag(gpa_pts==gpa_max) << "\n";
    std::cout << "  honors (yes)      : " << ok_flag(honors_yes_pts==honors_yes_max) << "\n";
    std::cout << "  honors (no)       : " << ok_flag(honors_no_pts==honors_no_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q27() {
    int asc_pts=0;
    const int asc_max=1;
    try {
        std::vector<int> arr = {64, 34, 25, 12, 22, 11, 90};
        bubble_sort(arr);
        std::vector<int> expected = {11, 12, 22, 25, 34, 64, 90};
        if (arr == expected) asc_pts = asc_max;
    } catch (...) {}

    int total = asc_max;
    int score = asc_pts;
    bool passed = (score == total);

    print_header("q27_bubble_sort", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  ascending sort    : " << ok_flag(asc_pts==asc_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q28() {
    int zero_pts=0, five_pts=0, neg_pts=0;
    const int zero_max=1, five_max=1, neg_max=1;
    try {
        if (factorial(0) == 1) zero_pts = zero_max;
        if (factorial(5) == 120) five_pts = five_max;
        if (factorial(-1) == -1) neg_pts = neg_max;
    } catch (...) {}

    int total = zero_max+five_max+neg_max;
    int score = zero_pts+five_pts+neg_pts;
    bool passed = (score == total);

    print_header("q28_factorial", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  factorial(0)      : " << ok_flag(zero_pts==zero_max) << "\n";
    std::cout << "  factorial(5)      : " << ok_flag(five_pts==five_max) << "\n";
    std::cout << "  factorial(-1)     : " << ok_flag(neg_pts==neg_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q29() {
    int fixed_pts=0;
    const int fixed_max=1;
    try {
        std::vector<std::string> list1 = add_student_fixed("Ali", nullptr);
        std::vector<std::string> list2 = add_student_fixed("Sara", nullptr);
        if (list1.size() == 1 && list2.size() == 1 && list1[0] == "Ali" && list2[0] == "Sara") {
            fixed_pts = fixed_max;
        }
    } catch (...) {}

    int total = fixed_max;
    int score = fixed_pts;
    bool passed = (score == total);

    print_header("q29_default_arg_bug", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  fixed version     : " << ok_flag(fixed_pts==fixed_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

int run_q30() {
    int basic_pts=0, dup_pts=0;
    const int basic_max=1, dup_max=1;
    try {
        std::vector<int> v1 = {234, 49, 54, 67, 344, 67};
        if (find_second_largest(v1) == 234) basic_pts = basic_max;
        std::vector<int> v2 = {5, 5, 5, 3, 3};
        if (find_second_largest(v2) == 3) dup_pts = dup_max;
    } catch (...) {}

    int total = basic_max+dup_max;
    int score = basic_pts+dup_pts;
    bool passed = (score == total);

    print_header("q30_second_largest", "MEDIUM", MEDIUM_WEIGHT);
    std::cout << "  basic case        : " << ok_flag(basic_pts==basic_max) << "\n";
    std::cout << "  with duplicates   : " << ok_flag(dup_pts==dup_max) << "\n";
    print_footer(passed, MEDIUM_WEIGHT);
    return passed ? MEDIUM_WEIGHT : 0;
}

// ==================== HARD QUESTIONS (12 pts each) ====================

int run_q3() {
    int push_pts=0, pop_pts=0, enq_pts=0, deq_pts=0;
    const int push_max=1, pop_max=1, enq_max=1, deq_max=1;
    try {
        Stack s;
        s.push(1); s.push(2); s.push(3);
        if (s.pop() == 3 && s.pop() == 2) pop_pts = pop_max;
        push_pts = push_max;

        Queue q;
        q.enqueue(1); q.enqueue(2); q.enqueue(3);
        if (q.dequeue() == 1 && q.dequeue() == 2) deq_pts = deq_max;
        enq_pts = enq_max;
    } catch (...) {}

    int total = push_max+pop_max+enq_max+deq_max;
    int score = push_pts+pop_pts+enq_pts+deq_pts;
    bool passed = (score == total);

    print_header("q3_stack_queue", "HARD", HARD_WEIGHT);
    std::cout << "  stack push        : " << ok_flag(push_pts==push_max) << "\n";
    std::cout << "  stack pop         : " << ok_flag(pop_pts==pop_max) << "\n";
    std::cout << "  queue enqueue     : " << ok_flag(enq_pts==enq_max) << "\n";
    std::cout << "  queue dequeue     : " << ok_flag(deq_pts==deq_max) << "\n";
    print_footer(passed, HARD_WEIGHT);
    return passed ? HARD_WEIGHT : 0;
}

int run_q9() {
    int simple_pts=0, carry_pts=0, diff_len_pts=0;
    const int simple_max=1, carry_max=1, diff_len_max=1;
    try {
        if (binary_addition("101", "110") == "1011") simple_pts = simple_max;
        if (binary_addition("111", "1") == "1000") carry_pts = carry_max;
        if (binary_addition("1", "1111") == "10000") diff_len_pts = diff_len_max;
    } catch (...) {}

    int total = simple_max+carry_max+diff_len_max;
    int score = simple_pts+carry_pts+diff_len_pts;
    bool passed = (score == total);

    print_header("q9_binary_addition", "HARD", HARD_WEIGHT);
    std::cout << "  simple addition   : " << ok_flag(simple_pts==simple_max) << "\n";
    std::cout << "  with carry        : " << ok_flag(carry_pts==carry_max) << "\n";
    std::cout << "  different lengths : " << ok_flag(diff_len_pts==diff_len_max) << "\n";
    print_footer(passed, HARD_WEIGHT);
    return passed ? HARD_WEIGHT : 0;
}

int run_q31() {
    int reverse_pts=0;
    const int reverse_max=1;
    try {
        int arr[] = {1, 2, 3, 4, 5};
        ListNode* head = create_list(arr, 5);
        ListNode* reversed_head = reverse_list(head);
        // Check if reversed correctly
        std::vector<int> result;
        ListNode* curr = reversed_head;
        while (curr) { result.push_back(curr->val); curr = curr->next; }
        std::vector<int> expected = {5, 4, 3, 2, 1};
        if (result == expected) reverse_pts = reverse_max;
        free_list(reversed_head);
    } catch (...) {}

    int total = reverse_max;
    int score = reverse_pts;
    bool passed = (score == total);

    print_header("q31_reverse_list", "HARD", HARD_WEIGHT);
    std::cout << "  reverse list      : " << ok_flag(reverse_pts==reverse_max) << "\n";
    print_footer(passed, HARD_WEIGHT);
    return passed ? HARD_WEIGHT : 0;
}

int run_q32() {
    int found_pts=0, not_found_pts=0;
    const int found_max=1, not_found_max=1;
    try {
        int arr[] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
        if (binary_search(arr, 10, 16) == 4) found_pts = found_max;
        if (binary_search(arr, 10, 100) == -1) not_found_pts = not_found_max;
    } catch (...) {}

    int total = found_max+not_found_max;
    int score = found_pts+not_found_pts;
    bool passed = (score == total);

    print_header("q32_binary_search", "HARD", HARD_WEIGHT);
    std::cout << "  element found     : " << ok_flag(found_pts==found_max) << "\n";
    std::cout << "  element not found : " << ok_flag(not_found_pts==not_found_max) << "\n";
    print_footer(passed, HARD_WEIGHT);
    return passed ? HARD_WEIGHT : 0;
}

int run_q33() {
    int deep_copy_pts=0;
    const int deep_copy_max=1;
    try {
        // Test that IntArray properly handles copy (needs copy constructor)
        IntArray a(42);
        IntArray b = a;  // Copy
        a.setValue(100);
        // If deep copy works, b should still have 42
        if (b.getValue() == 42) deep_copy_pts = deep_copy_max;
    } catch (...) {}

    int total = deep_copy_max;
    int score = deep_copy_pts;
    bool passed = (score == total);

    print_header("q33_copy_constructor", "HARD", HARD_WEIGHT);
    std::cout << "  deep copy fix     : " << ok_flag(deep_copy_pts==deep_copy_max) << "\n";
    print_footer(passed, HARD_WEIGHT);
    return passed ? HARD_WEIGHT : 0;
}

// ==================== RUN ALL ====================

void run_all() {
    int total_score = 0;
    int easy_score = 0, medium_score = 0, hard_score = 0;
    int max_score = 17 * EASY_WEIGHT + 11 * MEDIUM_WEIGHT + 5 * HARD_WEIGHT;  // 51 + 77 + 60 = 188

    std::cout << "\n" << YELLOW << "===== RUNNING ALL TESTS =====" << RESET << "\n\n";

    // Easy questions (17 questions × 3 pts = 51 pts)
    easy_score += run_q1();
    easy_score += run_q5();
    easy_score += run_q6();
    easy_score += run_q8();
    easy_score += run_q10();
    easy_score += run_q11();
    easy_score += run_q12();
    easy_score += run_q13();
    easy_score += run_q14();
    easy_score += run_q15();
    easy_score += run_q16();
    easy_score += run_q17();
    easy_score += run_q18();
    easy_score += run_q19();
    easy_score += run_q20();
    easy_score += run_q21();
    easy_score += run_q22();

    // Medium questions (11 questions × 7 pts = 77 pts)
    medium_score += run_q2();
    medium_score += run_q4();
    medium_score += run_q7();
    medium_score += run_q23();
    medium_score += run_q24();
    medium_score += run_q25();
    medium_score += run_q26();
    medium_score += run_q27();
    medium_score += run_q28();
    medium_score += run_q29();
    medium_score += run_q30();

    // Hard questions (5 questions × 12 pts = 60 pts)
    hard_score += run_q3();
    hard_score += run_q9();
    hard_score += run_q31();
    hard_score += run_q32();
    hard_score += run_q33();

    total_score = easy_score + medium_score + hard_score;

    std::cout << "\n" << YELLOW << "===== FINAL SCORE =====" << RESET << "\n";
    std::cout << "Easy   (17 × 3 pts): " << easy_score << "/51\n";
    std::cout << "Medium (11 × 7 pts): " << medium_score << "/77\n";
    std::cout << "Hard   ( 5 × 12 pts): " << hard_score << "/60\n";
    std::cout << "----------------------------------------\n";
    if (total_score == max_score) {
        std::cout << GREEN << "GRAND TOTAL: " << total_score << "/" << max_score << " pts - PERFECT SCORE!" << RESET << "\n";
    } else {
        std::cout << YELLOW << "GRAND TOTAL: " << total_score << "/" << max_score << " pts" << RESET << "\n";
    }
}

int main(int argc, char* argv[]) {
    if (argc > 1) {
        std::string arg = argv[1];
        if (arg == "all" || arg == "34") { run_all(); return 0; }
        if (arg == "0") return 0;
        try {
            int n = std::stoi(arg);
            switch(n) {
                case 1: run_q1(); return 0;
                case 2: run_q2(); return 0;
                case 3: run_q3(); return 0;
                case 4: run_q4(); return 0;
                case 5: run_q5(); return 0;
                case 6: run_q6(); return 0;
                case 7: run_q7(); return 0;
                case 8: run_q8(); return 0;
                case 9: run_q9(); return 0;
                case 10: run_q10(); return 0;
                case 11: run_q11(); return 0;
                case 12: run_q12(); return 0;
                case 13: run_q13(); return 0;
                case 14: run_q14(); return 0;
                case 15: run_q15(); return 0;
                case 16: run_q16(); return 0;
                case 17: run_q17(); return 0;
                case 18: run_q18(); return 0;
                case 19: run_q19(); return 0;
                case 20: run_q20(); return 0;
                case 21: run_q21(); return 0;
                case 22: run_q22(); return 0;
                case 23: run_q23(); return 0;
                case 24: run_q24(); return 0;
                case 25: run_q25(); return 0;
                case 26: run_q26(); return 0;
                case 27: run_q27(); return 0;
                case 28: run_q28(); return 0;
                case 29: run_q29(); return 0;
                case 30: run_q30(); return 0;
                case 31: run_q31(); return 0;
                case 32: run_q32(); return 0;
                case 33: run_q33(); return 0;
            }
        } catch (...) {}
    }

    while (true) {
        std::cout << "\nSelect a test to run (or 0 to exit, 34 to run all, q to quit):\n";
        std::cout << "=== EASY (3 pts each) ===\n";
        std::cout << " 1) q1_pointers         12) q12_techwars_loop   19) q19_temperature\n";
        std::cout << " 5) q5_oop              13) q13_countdown       20) q20_scope_bug\n";
        std::cout << " 6) q6_debugging        14) q14_vowel_counter   21) q21_even_sum\n";
        std::cout << " 8) q8_calculator       15) q15_percentage      22) q22_logic_bug\n";
        std::cout << "10) q10_statistics      16) q16_find_largest\n";
        std::cout << "11) q11_symbol_pattern  17) q17_leap_year\n";
        std::cout << "                        18) q18_array_access\n";
        std::cout << "\n=== MEDIUM (7 pts each) ===\n";
        std::cout << " 2) q2_linkedlist       23) q23_palindrome      27) q27_bubble_sort\n";
        std::cout << " 4) q4_procedural       24) q24_string_concat   28) q28_factorial\n";
        std::cout << " 7) q7_caeser_cipher    25) q25_matrix_add      29) q29_default_arg_bug\n";
        std::cout << "                        26) q26_student_class   30) q30_second_largest\n";
        std::cout << "\n=== HARD (12 pts each) ===\n";
        std::cout << " 3) q3_stack_queue       9) q9_binary_addition  31) q31_reverse_list\n";
        std::cout << "32) q32_binary_search   33) q33_copy_constructor\n";
        std::cout << "\n34) run all tests\n 0) exit\n\n";
        std::cout << "Enter choice: ";

        std::string line;
        std::getline(std::cin, line);
        if (line == "q" || line == "Q") break;
        if (line == "0") break;
        if (line == "34" || line == "all") { run_all(); continue; }

        try {
            int choice = std::stoi(line);
            switch(choice) {
                case 1: run_q1(); break;
                case 2: run_q2(); break;
                case 3: run_q3(); break;
                case 4: run_q4(); break;
                case 5: run_q5(); break;
                case 6: run_q6(); break;
                case 7: run_q7(); break;
                case 8: run_q8(); break;
                case 9: run_q9(); break;
                case 10: run_q10(); break;
                case 11: run_q11(); break;
                case 12: run_q12(); break;
                case 13: run_q13(); break;
                case 14: run_q14(); break;
                case 15: run_q15(); break;
                case 16: run_q16(); break;
                case 17: run_q17(); break;
                case 18: run_q18(); break;
                case 19: run_q19(); break;
                case 20: run_q20(); break;
                case 21: run_q21(); break;
                case 22: run_q22(); break;
                case 23: run_q23(); break;
                case 24: run_q24(); break;
                case 25: run_q25(); break;
                case 26: run_q26(); break;
                case 27: run_q27(); break;
                case 28: run_q28(); break;
                case 29: run_q29(); break;
                case 30: run_q30(); break;
                case 31: run_q31(); break;
                case 32: run_q32(); break;
                case 33: run_q33(); break;
                default: std::cout << "Invalid choice\n";
            }
        } catch (...) {
            std::cout << "Invalid input\n";
        }
    }
    return 0;
}
