#ifndef Q27_BUBBLE_SORT_H
#define Q27_BUBBLE_SORT_H

#include <vector>

// Sort array in ascending order using bubble sort
// This is a debugging exercise - the buggy version sorts in descending order
void bubble_sort(std::vector<int>& arr);

#endif // Q27_BUBBLE_SORT_H
