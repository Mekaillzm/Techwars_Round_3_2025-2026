#ifndef Q25_MATRIX_ADD_H
#define Q25_MATRIX_ADD_H

#include <vector>

// Add two matrices of the same dimensions
// Returns the sum matrix
std::vector<std::vector<int>> matrix_add(
    const std::vector<std::vector<int>>& a,
    const std::vector<std::vector<int>>& b);

#endif // Q25_MATRIX_ADD_H
