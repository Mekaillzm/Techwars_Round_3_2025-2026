#include "q26_student_class.h"

Student::Student(const std::string& name, int id, double gpa) {
    // TODO: Initialize member variables
}

std::string Student::getName() const {
    // TODO: Return name
    return "";
}

int Student::getId() const {
    // TODO: Return id
    return 0;
}

double Student::getGpa() const {
    // TODO: Return gpa
    return 0.0;
}

bool Student::isHonors() const {
    // TODO: Return true if GPA > 3.5
    return false;
}
