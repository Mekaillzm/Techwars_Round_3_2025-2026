#include "q24_string_concat.h"

std::string create_introduction(const std::string& name, int age) {
    // TODO: Return "My name is [name] and I am [age] years old."
    // Remember to convert age to string properly
    
    return "";
}
