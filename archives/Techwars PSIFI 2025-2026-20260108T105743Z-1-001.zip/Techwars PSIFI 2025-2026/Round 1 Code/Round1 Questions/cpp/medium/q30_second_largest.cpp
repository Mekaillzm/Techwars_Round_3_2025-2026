#include "q30_second_largest.h"
#include <stdexcept>
#include <limits>

int find_second_largest(const std::vector<int>& arr) {
    // TODO: Find second largest without sorting
    // Should handle duplicates properly
    // Throw runtime_error if less than 2 distinct elements
    
    if (arr.size() < 2) {
        throw std::runtime_error("need at least 2 elements");
    }
    
    return 0;
}
