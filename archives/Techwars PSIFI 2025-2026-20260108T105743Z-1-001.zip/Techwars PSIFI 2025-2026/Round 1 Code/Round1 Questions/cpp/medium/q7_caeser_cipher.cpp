#include "q7_caeser_cipher.h"

char shift_char(char c, int shift) {
    // TODO: Shift character by 'shift' positions in alphabet
    // 'a'-'z' should wrap around, 'A'-'Z' should wrap around
    // Non-letters should remain unchanged
    
    return c;
}

std::vector<std::string> all_caesar_shifts(const std::string &s) {
    // TODO: Return vector of 26 strings
    // shifts[0] = original, shifts[1] = shifted by 1, etc.
    
    std::vector<std::string> out;
    
    return out;
}
