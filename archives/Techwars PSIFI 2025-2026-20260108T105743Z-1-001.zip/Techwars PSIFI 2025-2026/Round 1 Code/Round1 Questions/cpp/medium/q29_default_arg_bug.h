#ifndef Q29_DEFAULT_ARG_BUG_H
#define Q29_DEFAULT_ARG_BUG_H

#include <vector>
#include <string>

// Add a student to a list - this demonstrates mutable default argument bug
// In Python this is a common bug; in C++ we simulate the concept
// Returns the updated list
std::vector<std::string> add_student(const std::string& name, std::vector<std::string> list = {});

// A corrected version that always creates a new list when none provided
std::vector<std::string> add_student_fixed(const std::string& name, std::vector<std::string>* list = nullptr);

#endif // Q29_DEFAULT_ARG_BUG_H
