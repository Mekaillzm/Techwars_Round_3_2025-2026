#include "q25_matrix_add.h"

std::vector<std::vector<int>> matrix_add(
    const std::vector<std::vector<int>>& a,
    const std::vector<std::vector<int>>& b) {
    // TODO: Add two matrices element by element
    // Assume matrices have the same dimensions
    
    std::vector<std::vector<int>> result;
    
    return result;
}
