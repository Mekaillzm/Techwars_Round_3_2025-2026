#ifndef Q7_CAESER_CIPHER_H
#define Q7_CAESER_CIPHER_H



#include <string>
#include <vector>

// Return a vector of 26 strings with all Caesar shifts of `s`.
std::vector<std::string> all_caesar_shifts(const std::string &s);


#endif // Q7_CAESER_CIPHER_H