#include "q4_procedural.h"
#include <stdexcept>
#include <algorithm>

std::vector<std::vector<int>> transpose(const std::vector<std::vector<int>>& matrix) {
    // TODO: Return the transpose of the matrix
    // Rows become columns and vice versa
    
    return {};
}

std::vector<std::vector<int>> rotate_right(const std::vector<std::vector<int>>& matrix) {
    // TODO: Rotate the matrix 90 degrees clockwise
    // Hint: transpose then reverse each row
    
    return {};
}
