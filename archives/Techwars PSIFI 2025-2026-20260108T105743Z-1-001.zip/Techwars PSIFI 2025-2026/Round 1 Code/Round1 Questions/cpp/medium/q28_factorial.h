#ifndef Q28_FACTORIAL_H
#define Q28_FACTORIAL_H

// Calculate factorial recursively
// Returns -1 for negative input
long long factorial(int n);

#endif // Q28_FACTORIAL_H
