#ifndef Q30_SECOND_LARGEST_H
#define Q30_SECOND_LARGEST_H

#include <vector>

// Find the second largest element in an array
// Do not sort - find in one or two passes
// Throws runtime_error if array has less than 2 distinct elements
int find_second_largest(const std::vector<int>& arr);

#endif // Q30_SECOND_LARGEST_H
