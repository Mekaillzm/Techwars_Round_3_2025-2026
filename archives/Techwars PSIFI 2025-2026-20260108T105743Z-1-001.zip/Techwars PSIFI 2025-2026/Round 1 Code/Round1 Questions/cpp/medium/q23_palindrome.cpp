#include "q23_palindrome.h"
#include <cctype>

bool is_palindrome(const std::string& str) {
    // TODO: Check if string is a palindrome using a loop
    // Case-insensitive, ignore non-alphanumeric characters
    
    return false;
}
