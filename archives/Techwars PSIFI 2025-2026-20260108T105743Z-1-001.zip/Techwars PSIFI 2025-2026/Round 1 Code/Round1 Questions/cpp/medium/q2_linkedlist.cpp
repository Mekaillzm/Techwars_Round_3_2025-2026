#include "q2_linkedlist.h"
#include <stdexcept>

LinkedList::LinkedList(): head(nullptr) {}

LinkedList::~LinkedList() {
    // TODO: Free all nodes to prevent memory leaks
    
}

void LinkedList::insert_at_head(int value) {
    // TODO: Insert a new node at the head of the list
    
}

void LinkedList::insert_at_tail(int value) {
    // TODO: Insert a new node at the tail of the list
    
}

bool LinkedList::delete_value(int value) {
    // TODO: Delete first occurrence of value, return true if found
    
    return false;
}

std::vector<int> LinkedList::to_vector() const {
    // TODO: Convert linked list to vector
    
    std::vector<int> out;
    return out;
}
