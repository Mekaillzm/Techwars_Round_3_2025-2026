#ifndef Q26_STUDENT_CLASS_H
#define Q26_STUDENT_CLASS_H

#include <string>

// Student class with name, id, and gpa
// isHonors() returns true if GPA > 3.5
class Student {
public:
    Student(const std::string& name, int id, double gpa);
    
    std::string getName() const;
    int getId() const;
    double getGpa() const;
    bool isHonors() const;

private:
    std::string name_;
    int id_;
    double gpa_;
};

#endif // Q26_STUDENT_CLASS_H
