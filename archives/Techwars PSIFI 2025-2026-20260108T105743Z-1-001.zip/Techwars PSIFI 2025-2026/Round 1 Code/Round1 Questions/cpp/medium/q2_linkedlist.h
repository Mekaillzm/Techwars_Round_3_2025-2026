#ifndef Q2_LINKEDLIST_H
#define Q2_LINKEDLIST_H

#include <vector>

class LinkedList {
public:
    struct Node { int value; Node* next; Node(int v): value(v), next(nullptr) {} };
    LinkedList();
    ~LinkedList();

    void insert_at_head(int value);
    void insert_at_tail(int value);
    bool delete_value(int value); // deletes first occurrence
    std::vector<int> to_vector() const;

private:
    Node* head;
};

#endif // Q2_LINKEDLIST_H
