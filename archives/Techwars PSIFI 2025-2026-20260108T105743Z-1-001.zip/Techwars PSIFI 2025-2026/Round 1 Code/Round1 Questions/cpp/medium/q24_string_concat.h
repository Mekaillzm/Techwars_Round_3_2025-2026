#ifndef Q24_STRING_CONCAT_H
#define Q24_STRING_CONCAT_H

#include <string>

// Create an introduction string: "My name is [name] and I am [age] years old."
// This is a debugging exercise about type conversion in string concatenation
std::string create_introduction(const std::string& name, int age);

#endif // Q24_STRING_CONCAT_H
