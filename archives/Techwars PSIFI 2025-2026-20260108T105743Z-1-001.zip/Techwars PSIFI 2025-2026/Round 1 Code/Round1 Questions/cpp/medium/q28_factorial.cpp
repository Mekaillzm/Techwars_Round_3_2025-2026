#include "q28_factorial.h"

long long factorial(int n) {
    // TODO: Implement recursive factorial
    // Return -1 for negative input
    
    return 0;
}
