#ifndef Q23_PALINDROME_H
#define Q23_PALINDROME_H

#include <string>

// Check if a string is a palindrome (reads the same forwards and backwards)
// Do not use built-in reverse functions - use a loop
// Should be case-insensitive and ignore non-alphanumeric characters
bool is_palindrome(const std::string& str);

#endif // Q23_PALINDROME_H
