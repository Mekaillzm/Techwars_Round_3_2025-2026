#ifndef Q31_REVERSE_LIST_H
#define Q31_REVERSE_LIST_H

// Node structure for singly linked list
struct ListNode {
    int val;
    ListNode* next;
    ListNode(int x) : val(x), next(nullptr) {}
};

// Reverse a singly linked list
// Returns the new head of the reversed list
ListNode* reverse_list(ListNode* head);

// Helper to create list from vector (for testing)
ListNode* create_list(const int* arr, int size);

// Helper to free list memory
void free_list(ListNode* head);

#endif // Q31_REVERSE_LIST_H
