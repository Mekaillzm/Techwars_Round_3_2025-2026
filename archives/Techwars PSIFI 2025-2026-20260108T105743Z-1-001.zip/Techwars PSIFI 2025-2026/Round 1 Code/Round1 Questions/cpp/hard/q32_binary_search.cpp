#include "q32_binary_search.h"

int binary_search(const int* arr, int size, int target) {
    // BUGGY: Fix the bug to make binary search work correctly
    
    int low = 0;
    int high = size - 1;
    
    while (low <= high) {
        int mid = (low + high) / 2;
        
        if (arr[mid] == target) {
            return mid;
        }
        else if (arr[mid] < target) {
            low = mid;  
        }
        else {
            high = mid - 1;
        }
    }
    return -1;
}
