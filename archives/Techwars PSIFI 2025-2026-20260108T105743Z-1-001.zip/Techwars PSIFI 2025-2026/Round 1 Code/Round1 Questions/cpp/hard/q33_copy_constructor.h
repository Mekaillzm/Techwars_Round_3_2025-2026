#ifndef Q33_COPY_CONSTRUCTOR_H
#define Q33_COPY_CONSTRUCTOR_H

// IntArray class that demonstrates the need for proper copy constructor
// This is a debugging exercise - without copy constructor, double-free occurs
class IntArray {
public:
    IntArray(int val);
    
    // TODO: Add copy constructor to fix double-free bug
    // IntArray(const IntArray& other);
    
    ~IntArray();
    
    int getValue() const;
    void setValue(int val);

private:
    int* ptr;
};

#endif // Q33_COPY_CONSTRUCTOR_H
