#ifndef Q32_BINARY_SEARCH_H
#define Q32_BINARY_SEARCH_H

// Binary search in a sorted array
// Returns index of target, or -1 if not found
// This is a debugging exercise - the buggy version can infinite loop
int binary_search(const int* arr, int size, int target);

#endif // Q32_BINARY_SEARCH_H
