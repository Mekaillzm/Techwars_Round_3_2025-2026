#include "q33_copy_constructor.h"
#include <iostream>

IntArray::IntArray(int val) {
    ptr = new int;
    *ptr = val;
}

// BUGGY: Missing copy constructor causes double-free
// When an object is copied, both objects share the same pointer
// When both destructors run, the same memory is freed twice

// TODO: Add this copy constructor to fix the bug:
// IntArray::IntArray(const IntArray& other) {
//     ptr = new int;
//     *ptr = *(other.ptr);
// }

IntArray::~IntArray() {
    delete ptr;
}

int IntArray::getValue() const {
    return *ptr;
}

void IntArray::setValue(int val) {
    *ptr = val;
}
