#include "q3_stack_queue.h"
#include <stdexcept>

Stack::Stack() {}

void Stack::push(int x) {
    // TODO: Push x onto the stack
    
}

int Stack::pop() {
    // TODO: Remove and return top element, return 0 if empty
    
    return 0;
}

int Stack::peek() const {
    // TODO: Return top element without removing, return 0 if empty
    
    return 0;
}

bool Stack::is_empty() const {
    // TODO: Return true if stack is empty
    
    return true;
}

Queue::Queue() {}

void Queue::enqueue(int x) {
    // TODO: Add x to the back of the queue
    
}

int Queue::dequeue() {
    // TODO: Remove and return front element, return 0 if empty
    
    return 0;
}

int Queue::peek() const {
    // TODO: Return front element without removing, return 0 if empty
    
    return 0;
}

bool Queue::is_empty() const {
    // TODO: Return true if queue is empty
    
    return true;
}
