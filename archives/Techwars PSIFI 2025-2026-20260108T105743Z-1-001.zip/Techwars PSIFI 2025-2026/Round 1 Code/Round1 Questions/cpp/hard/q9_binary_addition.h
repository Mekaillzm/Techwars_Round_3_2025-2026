#ifndef Q9_BINARY_ADDITION_H
#define Q9_BINARY_ADDITION_H

#include <string>

// Binary addition of two binary strings of equal length
// Returns the result as a binary string (may be one bit longer due to carry)
std::string binary_addition(const std::string& x, const std::string& y);

#endif // Q9_BINARY_ADDITION_H
