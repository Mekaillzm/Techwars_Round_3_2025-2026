#ifndef Q3_STACK_QUEUE_H
#define Q3_STACK_QUEUE_H

#include <vector>

class Stack {
public:
    Stack();
    void push(int x);
    int pop();
    int peek() const;
    bool is_empty() const;
private:
    std::vector<int> data;
};

class Queue {
public:
    Queue();
    void enqueue(int x);
    int dequeue();
    int peek() const;
    bool is_empty() const;
private:
    std::vector<int> data;
};

#endif // Q3_STACK_QUEUE_H
