#include "q15_percentage.h"

float calculate_percentage(int obtained, int total) {
    // BUGGY: Integer division causes result to be 0
    // Fix to correctly calculate percentage
    
    float percentage = (obtained / total) * 100;  // BUG: integer division
    
    return percentage;
}
