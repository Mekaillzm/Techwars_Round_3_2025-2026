#include "q12_techwars_loop.h"

std::vector<std::string> techwars_sequence(int n) {
    // TODO: Implement the TechWars sequence
    // For each number from 1 to n:
    // - If divisible by both 3 and 5: "TechWars"
    // - If divisible by 3 only: "Tech"
    // - If divisible by 5 only: "Wars"
    // - Otherwise: the number as a string
    
    std::vector<std::string> result;
    
    return result;
}
