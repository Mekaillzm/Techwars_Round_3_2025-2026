#include "q22_logic_bug.h"

bool is_yes(char input) {
    // BUGGY: Uses && instead of || - impossible for input to be both 'y' AND 'Y'
    // Fix to check if input is 'y' OR 'Y'
    
    if (input == 'Y' && input == 'y') {  // BUG: should be ||
        return true;
    }
    return false;
}
