#ifndef Q8_CALCULATOR_H
#define Q8_CALCULATOR_H

// Calculator operations
// Implement basic arithmetic operations: add, subtract, multiply, divide, power, modulo

int add(int a, int b);
int subtract(int a, int b);
int multiply(int a, int b);
int integer_divide(int a, int b); // integer division
double real_divide(double a, double b); // real division, throws on divide by zero
double power(int base, int exp);
int modulo(int a, int b); // throws on b==0

#endif // Q8_CALCULATOR_H
