#ifndef Q1_POINTERS_H
#define Q1_POINTERS_H

#include <stdexcept>

// Swap values via pointers
void swap_by_ptrs(int* a, int* b);

// Return value at base_index + offset in array of given size. 
int get_offset_value(int* arr, int base_index, int offset, int size);

#endif // Q1_POINTERS_H
