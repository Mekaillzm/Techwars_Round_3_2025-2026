#ifndef Q5_OOP_H
#define Q5_OOP_H

class BankAccount {
public:
    BankAccount(double initial = 0.0);
    virtual ~BankAccount();
    virtual void deposit(double amount);
    virtual void withdraw(double amount); // throws on overdraft
    virtual double balance() const;
protected:
    double bal;
};

class SavingsAccount : public BankAccount {
public:
    SavingsAccount(double initial = 0.0, double interest_rate = 0.01);
    void apply_interest();
private:
    double rate;
};

#endif // Q5_OOP_H
