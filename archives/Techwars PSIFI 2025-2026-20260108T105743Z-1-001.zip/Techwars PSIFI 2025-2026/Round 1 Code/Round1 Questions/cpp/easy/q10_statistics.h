#ifndef Q10_STATISTICS_H
#define Q10_STATISTICS_H

#include <vector>

// Calculate mean of array elements
double calc_mean(const std::vector<int>& arr);

// Calculate median of array elements (handles both odd and even sized arrays)
double calc_median(std::vector<int> arr); // takes copy since may need to sort

// Calculate range (max - min) of array elements
int calc_range(const std::vector<int>& arr);

#endif // Q10_STATISTICS_H
