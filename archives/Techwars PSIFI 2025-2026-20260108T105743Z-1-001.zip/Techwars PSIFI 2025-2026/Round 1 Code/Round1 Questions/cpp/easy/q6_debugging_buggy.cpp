#include "q6_debugging_buggy.h"
#include <limits>
#include <stdexcept>

int find_max(const std::vector<int>& arr) {
    // BUGGY: Find and fix the bugs in this function
    // Should return the maximum element in the array
    // Should throw std::runtime_error for empty array
    
    if (arr.empty()) throw std::runtime_error("empty array");
    int m = 999; // BUG: Wrong initialization
    for (int x : arr) {
        if (x < m)  // BUG: Wrong comparison
            x = m; 
    }
    return m;
}

double safe_divide(double a, double b) {
    // BUGGY: Find and fix the bugs in this function
    // Should throw error when wrong
    
    return a / b;  
}
