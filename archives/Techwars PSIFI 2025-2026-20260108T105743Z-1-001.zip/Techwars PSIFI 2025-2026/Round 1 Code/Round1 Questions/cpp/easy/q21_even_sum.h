#ifndef Q21_EVEN_SUM_H
#define Q21_EVEN_SUM_H

// Calculate the sum of all even numbers from 1 to n (inclusive)
int sum_of_evens(int n);

#endif // Q21_EVEN_SUM_H
