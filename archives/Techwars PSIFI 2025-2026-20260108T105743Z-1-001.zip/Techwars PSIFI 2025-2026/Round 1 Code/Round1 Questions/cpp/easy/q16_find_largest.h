#ifndef Q16_FIND_LARGEST_H
#define Q16_FIND_LARGEST_H

#include <vector>

// Find the largest number in an array without using built-in max functions
int find_largest(const std::vector<int>& arr);

#endif // Q16_FIND_LARGEST_H
