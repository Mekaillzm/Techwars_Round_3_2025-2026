#ifndef Q14_VOWEL_COUNTER_H
#define Q14_VOWEL_COUNTER_H

#include <string>

// Count the number of vowels (a, e, i, o, u) in a string
// Should be case-insensitive
int count_vowels(const std::string& str);

#endif // Q14_VOWEL_COUNTER_H
