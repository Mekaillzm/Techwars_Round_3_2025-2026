#include "q19_temperature.h"

double fahrenheit_to_celsius(double fahrenheit) {
    // TODO: Implement F to C conversion
    // Formula: C = (F - 32) * 5 / 9
    
    return 0.0;
}

double celsius_to_fahrenheit(double celsius) {
    // TODO: Implement C to F conversion
    // Formula: F = C * 9 / 5 + 32
    
    return 0.0;
}
