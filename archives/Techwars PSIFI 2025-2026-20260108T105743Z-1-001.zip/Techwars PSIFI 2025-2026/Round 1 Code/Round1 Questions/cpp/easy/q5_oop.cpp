#include "q5_oop.h"
#include <iostream>
#include <stdexcept>

BankAccount::BankAccount(double initial): bal(initial) {}
BankAccount::~BankAccount() {}

void BankAccount::deposit(double amount) {
    // TODO: Add amount to balance (ignore negative amounts)
    
}

void BankAccount::withdraw(double amount) {
    // TODO: Subtract amount from balance
    // Should throw exception if amount > balance (overdraft)
    
}

double BankAccount::balance() const {
    // TODO: Return current balance
    
    return 0.0;
}

SavingsAccount::SavingsAccount(double initial, double interest_rate): BankAccount(initial), rate(interest_rate) {}

void SavingsAccount::apply_interest() {
    // TODO: Add interest to balance (bal += bal * rate)
    
}
