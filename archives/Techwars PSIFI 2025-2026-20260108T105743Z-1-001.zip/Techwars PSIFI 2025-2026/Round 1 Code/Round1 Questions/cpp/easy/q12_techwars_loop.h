#ifndef Q12_TECHWARS_LOOP_H
#define Q12_TECHWARS_LOOP_H

#include <string>
#include <vector>

// Print numbers from 1 to n, but:
// - For multiples of 3, output "Tech"
// - For multiples of 5, output "Wars"
// - For multiples of both 3 and 5, output "TechWars"
// Returns a vector of strings with the output for each number
std::vector<std::string> techwars_sequence(int n);

#endif // Q12_TECHWARS_LOOP_H
