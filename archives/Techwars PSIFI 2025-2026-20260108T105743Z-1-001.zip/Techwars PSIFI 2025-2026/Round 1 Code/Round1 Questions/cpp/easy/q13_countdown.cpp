#include "q13_countdown.h"

std::vector<std::string> countdown(int start) {
    // BUGGY: This has an infinite loop - fix it!
    // Should count down from start to 1, then add "Liftoff!"
    
    std::vector<std::string> result;
    int i = start;
    
    while (i > 0) {
        result.push_back(std::to_string(i));
        // BUG: Missing decrement - i--;
    }
    
    result.push_back("Liftoff!");
    return result;
}
