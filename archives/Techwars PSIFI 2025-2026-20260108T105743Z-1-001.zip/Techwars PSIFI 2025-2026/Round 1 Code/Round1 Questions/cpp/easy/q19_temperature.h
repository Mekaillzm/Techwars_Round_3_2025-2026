#ifndef Q19_TEMPERATURE_H
#define Q19_TEMPERATURE_H

// Convert Fahrenheit to Celsius
// Formula: C = (F - 32) * 5 / 9
double fahrenheit_to_celsius(double fahrenheit);

// Convert Celsius to Fahrenheit
// Formula: F = C * 9 / 5 + 32
double celsius_to_fahrenheit(double celsius);

#endif // Q19_TEMPERATURE_H
