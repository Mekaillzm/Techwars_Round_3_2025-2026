#ifndef Q13_COUNTDOWN_H
#define Q13_COUNTDOWN_H

#include <string>
#include <vector>

// Countdown from start to 1, then add "Liftoff!"
// Returns vector of strings: ["10", "9", ..., "1", "Liftoff!"]
// This is a debugging exercise - the buggy version has an infinite loop
std::vector<std::string> countdown(int start);

#endif // Q13_COUNTDOWN_H
