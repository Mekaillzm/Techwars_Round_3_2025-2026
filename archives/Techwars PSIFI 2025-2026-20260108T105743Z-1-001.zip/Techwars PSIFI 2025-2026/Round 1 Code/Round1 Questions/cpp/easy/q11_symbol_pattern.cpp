#include "q11_symbol_pattern.h"

std::string generate_symbol_pattern(int a, int b) {
    // TODO: Implement symbol pattern generation
    // 1. Calculate limit = larger / smaller
    // 2. For each index from 1 to limit (inclusive):
    //    - '*' for multiples of 10
    //    - '#' for multiples of 5 (not 10)
    //    - '-' otherwise
    // 3. Return the concatenated string
    
    std::string result = "";
    
    return result;
}
