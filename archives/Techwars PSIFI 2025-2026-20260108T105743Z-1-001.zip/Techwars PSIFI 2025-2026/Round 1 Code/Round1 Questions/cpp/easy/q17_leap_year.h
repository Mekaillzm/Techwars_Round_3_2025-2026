#ifndef Q17_LEAP_YEAR_H
#define Q17_LEAP_YEAR_H

// Check if a year is a leap year
// Rules: Divisible by 4, but if divisible by 100, must also be divisible by 400
bool is_leap_year(int year);

#endif // Q17_LEAP_YEAR_H
