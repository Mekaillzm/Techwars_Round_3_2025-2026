#include "q8_calculator.h"
#include <cmath>
#include <stdexcept>

int add(int a, int b) {
    // TODO: Implement addition
    return 0;
}

int subtract(int a, int b) {
    // TODO: Implement subtraction
    return 0;
}

int multiply(int a, int b) {
    // TODO: Implement multiplication
    return 0;
}

int integer_divide(int a, int b) {
    // TODO: Implement integer division
    // Should handle divide by zero
    return 0;
}

double real_divide(double a, double b) {
    // TODO: Implement real division
    // Should throw on divide by zero
    return 0.0;
}

double power(int base, int exp) {
    // TODO: Implement exponentiation
    return 0.0;
}

int modulo(int a, int b) {
    // TODO: Implement modulo operation
    // Should throw on b==0
    return 0;
}
