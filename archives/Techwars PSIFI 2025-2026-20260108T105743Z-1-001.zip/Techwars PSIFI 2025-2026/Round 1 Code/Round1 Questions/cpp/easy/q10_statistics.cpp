#include "q10_statistics.h"
#include <algorithm>
#include <stdexcept>

double calc_mean(const std::vector<int>& arr) {
    // TODO: Calculate and return the mean (average) of elements
    // Should handle empty array appropriately
    
    return 0.0;
}

double calc_median(std::vector<int> arr) {
    // TODO: Calculate and return the median
    // Sort array first, then find middle element(s)
    // For even-sized arrays, return average of two middle elements
    
    return 0.0;
}

int calc_range(const std::vector<int>& arr) {
    // TODO: Calculate and return the range (max - min)
    // Should handle empty array appropriately
    
    return 0;
}
