#ifndef Q20_SCOPE_BUG_H
#define Q20_SCOPE_BUG_H

// Calculate a total - this is a debugging exercise about variable scope
// The buggy version declares total inside an if block, losing it after the block
int calculate_total(bool should_calculate, int base, int addition);

#endif // Q20_SCOPE_BUG_H
