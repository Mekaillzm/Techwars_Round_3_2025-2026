#include "q1_pointers.h"


void swap_by_ptrs(int* a, int* b) {
    // TODO: Swap the values pointed to by a and b
    // Handle null pointers appropriately
    
}

int get_offset_value(int* arr, int base_index, int offset, int size) {
    // TODO: Return the value at arr[base_index + offset]
    // Handle invalid indices by returning 0
    
    return 0;
}
