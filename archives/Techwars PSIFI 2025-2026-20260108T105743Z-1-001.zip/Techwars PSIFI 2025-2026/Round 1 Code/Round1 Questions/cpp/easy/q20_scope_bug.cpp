#include "q20_scope_bug.h"

int calculate_total(bool should_calculate, int base, int addition) {
    // BUGGY: Variable scope issue - total is declared inside if block
    // Fix to make total accessible after the if block
    
    if (should_calculate) {
        int total = base;  // BUG: declared inside block
        total = total + addition;
    }
    
    // BUG: total is not accessible here
    return 0;  // Should return total
}
