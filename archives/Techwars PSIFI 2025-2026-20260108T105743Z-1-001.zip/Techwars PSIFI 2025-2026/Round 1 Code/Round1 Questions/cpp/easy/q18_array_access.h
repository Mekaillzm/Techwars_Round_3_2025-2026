#ifndef Q18_ARRAY_ACCESS_H
#define Q18_ARRAY_ACCESS_H

#include <vector>

// Get the last element of a vector safely
// This is a debugging exercise - the buggy version accesses index [size] instead of [size-1]
int get_last_element(const std::vector<int>& arr);

#endif // Q18_ARRAY_ACCESS_H
