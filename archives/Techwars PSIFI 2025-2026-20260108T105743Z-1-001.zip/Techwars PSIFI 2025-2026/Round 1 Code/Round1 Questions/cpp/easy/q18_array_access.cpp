#include "q18_array_access.h"
#include <stdexcept>

int get_last_element(const std::vector<int>& arr) {
    // BUGGY: Accesses wrong index
    // Should return the last element of the array
    
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }
    
    return arr[arr.size()];  // BUG: should be arr[arr.size() - 1]
}
