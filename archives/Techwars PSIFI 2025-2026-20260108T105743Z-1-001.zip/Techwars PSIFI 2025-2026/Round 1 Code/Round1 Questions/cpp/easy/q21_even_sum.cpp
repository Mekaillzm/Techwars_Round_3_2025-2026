#include "q21_even_sum.h"

int sum_of_evens(int n) {
    // TODO: Calculate sum of all even numbers from 1 to n
    
    int sum = 0;
    
    return sum;
}
