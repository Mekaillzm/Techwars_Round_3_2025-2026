#include "q16_find_largest.h"
#include <stdexcept>

int find_largest(const std::vector<int>& arr) {
    // TODO: Find the largest element without using std::max_element
    // Should throw std::runtime_error for empty array
    
    if (arr.empty()) {
        throw std::runtime_error("empty array");
    }

    
    
    int largest = 0;
    
    return largest;
}
