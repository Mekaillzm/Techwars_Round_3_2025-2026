#include "q17_leap_year.h"

bool is_leap_year(int year) {
    // TODO: Implement leap year check
    // Divisible by 4, but if divisible by 100, must also be divisible by 400
    
    return false;
}
