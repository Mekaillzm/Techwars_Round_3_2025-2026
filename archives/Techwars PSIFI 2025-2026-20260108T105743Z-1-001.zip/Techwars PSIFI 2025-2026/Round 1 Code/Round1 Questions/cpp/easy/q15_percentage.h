#ifndef Q15_PERCENTAGE_H
#define Q15_PERCENTAGE_H

// Calculate percentage: (obtained / total) * 100
// This is a debugging exercise - the buggy version uses integer division
float calculate_percentage(int obtained, int total);

#endif // Q15_PERCENTAGE_H
