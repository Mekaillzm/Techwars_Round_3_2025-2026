#include "q14_vowel_counter.h"
#include <cctype>

int count_vowels(const std::string& str) {
    // TODO: Count vowels (a, e, i, o, u) case-insensitively
    
    int count = 0;
    
    return count;
}
