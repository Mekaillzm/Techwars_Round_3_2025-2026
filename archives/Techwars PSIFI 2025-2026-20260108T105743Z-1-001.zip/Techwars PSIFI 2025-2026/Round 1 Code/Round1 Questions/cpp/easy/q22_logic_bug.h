#ifndef Q22_LOGIC_BUG_H
#define Q22_LOGIC_BUG_H

// Check if a character is 'y' or 'Y' (case insensitive yes)
// This is a debugging exercise - the buggy version uses && instead of ||
bool is_yes(char input);

#endif // Q22_LOGIC_BUG_H
