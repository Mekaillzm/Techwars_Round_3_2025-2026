#ifndef Q6_DEBUGGING_BUGGY_H
#define Q6_DEBUGGING_BUGGY_H

#include <vector>

int find_max(const std::vector<int>& arr); // should throw on empty

double safe_divide(double a, double b); // should throw on b==0

#endif // Q6_DEBUGGING_BUGGY_H
