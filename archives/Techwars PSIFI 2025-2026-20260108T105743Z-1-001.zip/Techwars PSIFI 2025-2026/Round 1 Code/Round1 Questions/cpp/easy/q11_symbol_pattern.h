#ifndef Q11_SYMBOL_PATTERN_H
#define Q11_SYMBOL_PATTERN_H

#include <string>

// Generate a symbol pattern string based on two integers
// Divides larger by smaller to get limit, then for each index from 1 to limit:
// - Output '*' for multiples of 10
// - Output '#' for multiples of 5 (but not 10)
// - Output '-' otherwise
std::string generate_symbol_pattern(int a, int b);

#endif // Q11_SYMBOL_PATTERN_H
