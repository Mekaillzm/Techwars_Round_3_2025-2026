# TechWars Round 1 — Programming Challenge

Welcome to Round 1 of TechWars! This round tests your skills in C++ or Python across 33 questions organized by difficulty.

## Scoring

| Difficulty | Points per Question | Questions |
|------------|---------------------|-----------|
| Easy       | 3 pts               | 17 questions (51 pts max) |
| Medium     | 7 pts               | 11 questions (77 pts max) |
| Hard       | 12 pts              | 5 questions (60 pts max) |

**Total: 188 points maximum**

---

## Question List

### Easy (3 pts each)
| # | File | Description |
|---|------|-------------|
| q1 | `q1_pointers` | Pointer swap and offset operations |
| q5 | `q5_oop` | Bank account OOP (deposit/withdraw/balance) |
| q6 | `q6_debugging_buggy` | Fix bugs in find_max and safe_divide |
| q8 | `q8_calculator` | Basic arithmetic operations |
| q10 | `q10_statistics` | Calculate mean, median, and range |
| q11 | `q11_symbol_pattern` | Generate symbol patterns based on divisibility |
| q12 | `q12_techwars_loop` | FizzBuzz variant (Tech/Wars/TechWars) |
| q13 | `q13_countdown` | Fix infinite loop bug in countdown |
| q14 | `q14_vowel_counter` | Count vowels in a string |
| q15 | `q15_percentage` | Fix integer division bug in percentage calc |
| q16 | `q16_find_largest` | Find largest element without built-ins |
| q17 | `q17_leap_year` | Leap year checker |
| q18 | `q18_array_access` | Fix off-by-one array access bug |
| q19 | `q19_temperature` | Fahrenheit/Celsius conversion |
| q20 | `q20_scope_bug` | Fix variable scope bug |
| q21 | `q21_even_sum` | Sum of even numbers 1 to n |
| q22 | `q22_logic_bug` | Fix AND vs OR logic bug |

### Medium (7 pts each)
| # | File | Description |
|---|------|-------------|
| q2 | `q2_linkedlist` | Singly linked list implementation |
| q4 | `q4_procedural` | Matrix transpose and rotate operations |
| q7 | `q7_caeser_cipher` | Generate all 26 Caesar cipher shifts |
| q23 | `q23_palindrome` | Palindrome checker (ignore case/non-alpha) |
| q24 | `q24_string_concat` | Fix type error in string concatenation |
| q25 | `q25_matrix_add` | Matrix addition |
| q26 | `q26_student_class` | Student class with GPA/honors check |
| q27 | `q27_bubble_sort` | Fix descending→ascending sort bug |
| q28 | `q28_factorial` | Recursive factorial |
| q29 | `q29_default_arg_bug` | Fix mutable default argument bug |
| q30 | `q30_second_largest` | Find second largest element |

### Hard (12 pts each)
| # | File | Description |
|---|------|-------------|
| q3 | `q3_stack_queue` | Stack and Queue implementation |
| q9 | `q9_binary_addition` | Binary string addition with carry |
| q31 | `q31_reverse_list` | Reverse linked list by pointer manipulation |
| q32 | `q32_binary_search` | Fix infinite loop bug in binary search |
| q33 | `q33_copy_constructor` | Fix double-free with copy constructor(C++ Exclusive) |

---

## Directory Structure

```
Round1/
├── cpp/
│   ├── test_runner.cpp
│   ├── easy/       (q1, q5, q6, q8, q10-q22)
│   ├── medium/     (q2, q4, q7, q23-q30)
│   └── hard/       (q3, q9, q31-q33)
└── python/
    ├── test_runner.py
    ├── easy/       (q1, q5, q6, q8, q10-q22)
    ├── medium/     (q2, q4, q7, q23-q30)
    └── hard/       (q3, q9, q31-q33)
```

---

## Running Tests (Windows)

### Prerequisites
- **C++**: Install MinGW-w64 or use Visual Studio with g++/cl compiler
- **Python**: Install Python 3.8+ from python.org

### C++ Tests

1. Open Command Prompt or PowerShell
2. Navigate to the `Round1/cpp` directory:
   ```cmd
   cd Round1\cpp
   ```

3. Compile the test runner (using g++ from MinGW):
   ```cmd
   g++ -std=c++17 -Og -Wall -o test_runner.exe ^
       test_runner.cpp ^
       easy\q1_pointers.cpp easy\q5_oop.cpp easy\q6_debugging_buggy.cpp ^
       easy\q8_calculator.cpp easy\q10_statistics.cpp easy\q11_symbol_pattern.cpp ^
       easy\q12_techwars_loop.cpp easy\q13_countdown.cpp easy\q14_vowel_counter.cpp ^
       easy\q15_percentage.cpp easy\q16_find_largest.cpp easy\q17_leap_year.cpp ^
       easy\q18_array_access.cpp easy\q19_temperature.cpp easy\q20_scope_bug.cpp ^
       easy\q21_even_sum.cpp easy\q22_logic_bug.cpp ^
       medium\q2_linkedlist.cpp medium\q4_procedural.cpp medium\q7_caeser_cipher.cpp ^
       medium\q23_palindrome.cpp medium\q24_string_concat.cpp medium\q25_matrix_add.cpp ^
       medium\q26_student_class.cpp medium\q27_bubble_sort.cpp medium\q28_factorial.cpp ^
       medium\q29_default_arg_bug.cpp medium\q30_second_largest.cpp ^
       hard\q3_stack_queue.cpp hard\q9_binary_addition.cpp hard\q31_reverse_list.cpp ^
       hard\q32_binary_search.cpp hard\q33_copy_constructor.cpp
   ```

4. Run the tests:
   ```cmd
   test_runner.exe all
   ```

   Or run specific difficulty:
   ```cmd
   test_runner.exe easy
   test_runner.exe medium
   test_runner.exe hard
   ```

### Python Tests

1. Open Command Prompt or PowerShell
2. Navigate to the `Round1/python` directory:
   ```cmd
   cd Round1\python
   ```

3. Run the test runner:
   ```cmd
   python test_runner.py all
   ```

   Or run specific difficulty:
   ```cmd
   python test_runner.py easy
   python test_runner.py medium
   python test_runner.py hard
   ```

### Testing a Specific Question

You can test individual questions by specifying the question number:

**C++:**
```cmd
test_runner.exe q1
test_runner.exe q15
test_runner.exe q33
```

**Python:**
```cmd
python test_runner.py q1
python test_runner.py q15
python test_runner.py q33
```

This is useful when you want to focus on solving one question at a time without running the entire test suite.

---

## Tips

1. **Read the header files** (`.h`) to understand function signatures
2. **Check the comments** in Python files for expected behavior
3. **Debugging questions** have intentional bugs marked with comments
4. **TODO questions** have placeholders you need to implement
5. **Run tests** frequently to check your progress!
