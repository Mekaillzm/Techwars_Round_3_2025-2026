"""
Q8 (Python): Calculator operations.

Contract:
- Implement basic arithmetic functions: add, subtract, multiply, integer_divide, real_divide, power, modulo.
- `integer_divide(a, b)` returns integer division result.
- `real_divide(a, b)` returns float division result, raises ZeroDivisionError if b == 0.
- `power(base, exp)` returns base raised to the power of exp.
- `modulo(a, b)` returns a % b, raises ZeroDivisionError if b == 0.
"""


def add(a: int, b: int) -> int:
    # TODO: Implement addition
    return 0


def subtract(a: int, b: int) -> int:
    # TODO: Implement subtraction
    return 0


def multiply(a: int, b: int) -> int:
    # TODO: Implement multiplication
    return 0


def integer_divide(a: int, b: int) -> int:
    # TODO: Implement integer division
    # Should handle divide by zero
    return 0


def real_divide(a: float, b: float) -> float:
    # TODO: Implement real division
    # Should raise ZeroDivisionError on divide by zero
    return 0.0


def power(base: int, exp: int) -> float:
    # TODO: Implement exponentiation
    return 0.0


def modulo(a: int, b: int) -> int:
    # TODO: Implement modulo operation
    # Should raise ZeroDivisionError on b==0
    return 0
