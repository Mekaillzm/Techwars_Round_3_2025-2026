"""
Q20 (Python): Scope bug debugging exercise

Contract:
- Implement `calculate_total(should_calculate, base, addition)` that returns base + addition if should_calculate is True.
- This demonstrates variable scope issues (though Python's scoping is different from C++).
"""


def calculate_total(should_calculate: bool, base: int, addition: int) -> int:
    # BUGGY: Variable scope issue demonstration
    # In the buggy version, total might not be defined if should_calculate is False
    
    if should_calculate:
        total = base + addition
    
    # BUG: total is not defined if should_calculate is False
    return total  # Will raise UnboundLocalError
