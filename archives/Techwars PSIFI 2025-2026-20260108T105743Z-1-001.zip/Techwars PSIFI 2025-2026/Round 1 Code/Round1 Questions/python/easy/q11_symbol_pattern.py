"""
Q11 (Python): Symbol pattern generation.

Contract:
- Implement `generate_symbol_pattern(a, b)` which generates a pattern string.
- Divides larger by smaller to get limit.
- For each index from 1 to limit (inclusive):
  - '*' for multiples of 10
  - '#' for multiples of 5 (but not 10)
  - '-' otherwise
- Returns the concatenated pattern string.
"""


def generate_symbol_pattern(a: int, b: int) -> str:
    # TODO: Implement symbol pattern generation
    # 1. Calculate limit = larger / smaller (integer division)
    # 2. For each index from 1 to limit (inclusive):
    #    - '*' for multiples of 10
    #    - '#' for multiples of 5 (not 10)
    #    - '-' otherwise
    # 3. Return the concatenated string
    
    result = ""
    
    return result
