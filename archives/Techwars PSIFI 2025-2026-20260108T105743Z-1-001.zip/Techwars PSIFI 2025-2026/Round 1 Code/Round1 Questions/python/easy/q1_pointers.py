"""
Q1 (Python): Simulate pointer-like swap and offset operations on a mutable container.

Contract:
- Implement `swap_by_index(arr, i, j)` which swaps elements at indexes i and j in-place.
- Implement `get_offset_value(arr, base_index, offset)` which returns arr[base_index + offset].
- Raise IndexError for invalid indices.

Note: In C++ this problem will exercise raw pointers; in Python we use list indexing to simulate.
"""

from typing import List, Any


def swap_by_index(arr: List[Any], i: int, j: int) -> None:
    arr[i], arr[j] = arr[j], arr[i]




def get_offset_value(arr: List[Any], base_index: int, offset: int) -> Any:

    return
