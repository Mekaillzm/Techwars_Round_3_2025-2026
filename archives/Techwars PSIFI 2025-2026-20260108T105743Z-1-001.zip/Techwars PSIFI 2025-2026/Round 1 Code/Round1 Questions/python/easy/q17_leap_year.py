"""
Q17 (Python): Leap Year checker

Contract:
- Implement `is_leap_year(year)` that returns True if year is a leap year.
- Rules: Divisible by 4, but if divisible by 100, must also be divisible by 400.
"""


def is_leap_year(year: int) -> bool:
    # TODO: Implement leap year check
    
    return False
