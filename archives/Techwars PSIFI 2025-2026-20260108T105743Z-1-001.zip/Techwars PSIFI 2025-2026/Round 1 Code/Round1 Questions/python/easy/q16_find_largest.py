"""
Q16 (Python): Find largest element

Contract:
- Implement `find_largest(arr)` that finds the largest element without using max().
- Should raise ValueError for empty array.
"""
from typing import List


def find_largest(arr: List[int]) -> int:
    # TODO: Find the largest element without using built-in max()
    
    if not arr:
        raise ValueError("empty array")
    
    largest = 0
    
    return largest
