"""
Q18 (Python): Array access debugging exercise

Contract:
- Implement `get_last_element(arr)` that returns the last element.
- This is a debugging exercise - the buggy version accesses index [len] instead of [len-1].
- Should raise ValueError for empty array.
"""
from typing import List


def get_last_element(arr: List[int]) -> int:
    # BUGGY: Accesses wrong index causing IndexError
    
    if not arr:
        raise ValueError("empty array")
    
    return arr[len(arr)]  # BUG: should be arr[len(arr) - 1] or arr[-1]
