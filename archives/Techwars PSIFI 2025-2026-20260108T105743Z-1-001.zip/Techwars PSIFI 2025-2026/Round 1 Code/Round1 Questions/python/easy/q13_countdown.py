"""
Q13 (Python): Countdown debugging exercise

Contract:
- Implement `countdown(start)` that returns a list: [start, start-1, ..., 1, "Liftoff!"]
- This is a debugging exercise - the buggy version has an infinite loop
"""
from typing import List, Union


def countdown(start: int) -> List[Union[int, str]]:
    # BUGGY: This has an infinite loop - fix it!
    
    result = []
    i = start
    
    while i > 0:
        result.append(i)
        # BUG: Missing decrement - i -= 1
    
    result.append("Liftoff!")
    return result
