"""
Q12 (Python): TechWars Loop (FizzBuzz variant)

Contract:
- Implement `techwars_sequence(n)` that returns a list of strings from 1 to n.
- For multiples of 3: "Tech"
- For multiples of 5: "Wars"
- For multiples of both 3 and 5: "TechWars"
- Otherwise: the number as a string
"""
from typing import List


def techwars_sequence(n: int) -> List[str]:
    # TODO: Implement the TechWars sequence
    
    result = []
    
    return result
