"""
Q21 (Python): Sum of even numbers

Contract:
- Implement `sum_of_evens(n)` that returns the sum of all even numbers from 1 to n (inclusive).
"""


def sum_of_evens(n: int) -> int:
    # TODO: Calculate sum of all even numbers from 1 to n
    
    total = 0
    
    return total
