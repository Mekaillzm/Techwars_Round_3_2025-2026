"""
Q5 (Python): OOP — implement a simple bank account hierarchy.

Contract:
- Implement `BankAccount` base class with methods: deposit(amount), withdraw(amount), balance.
- Implement `SavingsAccount` derived class with interest_rate and method `apply_interest()`.
- Raise ValueError for invalid operations (negative deposit/withdraw, overdraft).
"""
from typing import Any


class BankAccount:
    def __init__(self, initial: float = 0.0):
        
        return

    def deposit(self, amount: float) -> None:
        
        return

    def withdraw(self, amount: float) -> None:
        
        return

    def balance(self) -> float:
        
        return


class SavingsAccount(BankAccount):
    def __init__(self, initial: float = 0.0, interest_rate: float = 0.01):
        
        return

    def apply_interest(self) -> None:
        
        return
