"""
Q15 (Python): Percentage calculation debugging exercise

Contract:
- Implement `calculate_percentage(obtained, total)` that returns (obtained/total)*100
- This is a debugging exercise - the buggy version uses integer division
"""


def calculate_percentage(obtained: int, total: int) -> float:
    # BUGGY: Integer division in Python 2 style causes issues
    # In Python 3 this works, but the concept is about ensuring float division
    # Fix to correctly calculate percentage
    
    percentage = (obtained // total) * 100  # BUG: using // instead of /
    
    return percentage
