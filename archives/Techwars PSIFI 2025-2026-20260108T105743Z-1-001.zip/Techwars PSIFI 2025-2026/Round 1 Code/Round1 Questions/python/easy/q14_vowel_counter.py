"""
Q14 (Python): Vowel Counter

Contract:
- Implement `count_vowels(s)` that counts vowels (a, e, i, o, u) in a string.
- Should be case-insensitive.
"""


def count_vowels(s: str) -> int:
    # TODO: Count vowels (a, e, i, o, u) case-insensitively
    
    count = 0
    
    return count
