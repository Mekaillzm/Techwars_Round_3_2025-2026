"""
Q22 (Python): Logic bug debugging exercise (AND vs OR)

Contract:
- Implement `is_yes(char)` that returns True if char is 'y' or 'Y'.
- This is a debugging exercise - the buggy version uses `and` instead of `or`.
"""


def is_yes(char: str) -> bool:
    # BUGGY: Uses 'and' instead of 'or' - impossible for char to be both 'y' AND 'Y'
    
    if char == 'Y' and char == 'y':  # BUG: should be 'or'
        return True
    return False
