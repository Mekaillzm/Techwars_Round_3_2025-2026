"""
Q19 (Python): Temperature conversion

Contract:
- Implement `fahrenheit_to_celsius(f)` using formula: C = (F - 32) * 5 / 9
- Implement `celsius_to_fahrenheit(c)` using formula: F = C * 9 / 5 + 32
"""


def fahrenheit_to_celsius(fahrenheit: float) -> float:
    # TODO: Convert Fahrenheit to Celsius
    
    return 0.0


def celsius_to_fahrenheit(celsius: float) -> float:
    # TODO: Convert Celsius to Fahrenheit
    
    return 0.0
