"""
Q10 (Python): Statistics — mean, median, and range calculations.

Contract:
- Implement `calc_mean(arr)` which returns the mean (average) of elements.
- Implement `calc_median(arr)` which returns the median (middle element or average of two middle elements).
- Implement `calc_range(arr)` which returns the range (max - min).
- Should handle empty arrays appropriately (raise ValueError).
"""
from typing import List


def calc_mean(arr: List[int]) -> float:
    # TODO: Calculate and return the mean (average) of elements
    # Should raise ValueError for empty array
    
    return 0.0


def calc_median(arr: List[int]) -> float:
    # TODO: Calculate and return the median
    # Sort array first, then find middle element(s)
    # For even-sized arrays, return average of two middle elements
    # Should raise ValueError for empty array
    
    return 0.0


def calc_range(arr: List[int]) -> int:
    # TODO: Calculate and return the range (max - min)
    # Should raise ValueError for empty array
    
    return 0
