"""
Q6 (Python): Debugging — a buggy implementation is provided. Students must find and fix errors to pass tests.

The provided buggy functions:
- `find_max(arr)`: should return maximum integer from arr; buggy for negative numbers or empty list.
- `safe_divide(a, b)`: should raise ZeroDivisionError if b == 0; bug handling.

Students will locate and fix the bugs.
"""
from typing import List


def find_max(arr: List[int]) -> int:
    
    if not arr:
        raise ValueError("empty array")
    
    m = 'inf'  
    for x in arr:
        if x > m:
            m = x
    return m


def safe_divide(a: float, b: float) -> float:
    
    return a / b
    
