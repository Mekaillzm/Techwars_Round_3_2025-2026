
from typing import List


def shift_char(c: str, sh: int) -> str:
    
    return


def all_caesar_shifts(s: str) -> List[str]:

    out: List[str] = []
    

    return out

