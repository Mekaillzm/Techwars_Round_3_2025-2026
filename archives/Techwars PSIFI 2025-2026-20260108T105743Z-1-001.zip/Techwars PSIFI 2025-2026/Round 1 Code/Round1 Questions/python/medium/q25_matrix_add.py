"""
Q25 (Python): Matrix addition

Contract:
- Implement `matrix_add(a, b)` that adds two matrices of the same dimensions.
- Returns the sum matrix.
"""
from typing import List


def matrix_add(a: List[List[int]], b: List[List[int]]) -> List[List[int]]:
    # TODO: Add two matrices element by element
    
    result = []
    
    return result
