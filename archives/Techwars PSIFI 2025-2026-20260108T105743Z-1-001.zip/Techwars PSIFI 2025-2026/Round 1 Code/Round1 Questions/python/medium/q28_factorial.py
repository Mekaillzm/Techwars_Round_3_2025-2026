"""
Q28 (Python): Recursive factorial

Contract:
- Implement `factorial(n)` recursively.
- Returns -1 for negative input.
"""


def factorial(n: int) -> int:
    # TODO: Implement recursive factorial
    # Return -1 for negative input
    
    return 0
