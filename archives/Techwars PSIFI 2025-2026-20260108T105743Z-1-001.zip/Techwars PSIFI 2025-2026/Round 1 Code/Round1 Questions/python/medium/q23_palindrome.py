"""
Q23 (Python): Palindrome checker

Contract:
- Implement `is_palindrome(s)` that checks if a string is a palindrome.
- Do not use built-in reverse ([::-1]) - use a loop.
- Should be case-insensitive and ignore non-alphanumeric characters.
"""


def is_palindrome(s: str) -> bool:
    # TODO: Check if string is a palindrome using a loop
    # Case-insensitive, ignore non-alphanumeric characters
    
    return False
