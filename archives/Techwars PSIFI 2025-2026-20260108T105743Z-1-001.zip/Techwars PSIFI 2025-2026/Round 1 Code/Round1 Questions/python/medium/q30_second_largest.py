"""
Q30 (Python): Find second largest element

Contract:
- Implement `find_second_largest(arr)` that finds the second largest element.
- Do not sort - find in one or two passes.
- Should raise ValueError if array has less than 2 distinct elements.
"""
from typing import List


def find_second_largest(arr: List[int]) -> int:
    # TODO: Find second largest without sorting
    # Handle duplicates properly
    
    if len(arr) < 2:
        raise ValueError("need at least 2 elements")
    
    return 0
