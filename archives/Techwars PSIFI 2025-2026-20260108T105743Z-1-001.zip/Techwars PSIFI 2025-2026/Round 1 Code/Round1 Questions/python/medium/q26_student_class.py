"""
Q26 (Python): Student class OOP

Contract:
- Create a class `Student` with attributes: name, id, gpa.
- Include a constructor to set these values.
- Include a method `is_honors()` that returns True if GPA > 3.5.
"""


class Student:
    def __init__(self, name: str, student_id: int, gpa: float):
        # TODO: Initialize attributes
        pass
    
    def get_name(self) -> str:
        # TODO: Return name
        return ""
    
    def get_id(self) -> int:
        # TODO: Return id
        return 0
    
    def get_gpa(self) -> float:
        # TODO: Return gpa
        return 0.0
    
    def is_honors(self) -> bool:
        # TODO: Return True if GPA > 3.5
        return False
