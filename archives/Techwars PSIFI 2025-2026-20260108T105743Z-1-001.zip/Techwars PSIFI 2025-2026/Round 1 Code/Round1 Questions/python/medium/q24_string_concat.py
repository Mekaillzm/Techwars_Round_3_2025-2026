"""
Q24 (Python): String concatenation type error debugging exercise

Contract:
- Implement `create_introduction(name, age)` that returns "My name is [name] and I am [age] years old."
"""


def create_introduction(name: str, age: int) -> str:

    
    return "My name is " + name + " and I am " + age + " years old."  
