"""
Q4 (Python): Procedural programming — matrix transpose and rotate operations.

Contract:
- Implement `transpose(matrix)` which returns new matrix transposed.
- Implement `rotate_right(matrix)` which returns new matrix rotated 90 degrees clockwise.
- All inputs are lists of lists of ints; treat non-square matrices as well.
"""
from typing import List


def transpose(matrix: List[List[int]]) -> List[List[int]]:
    
    return


def rotate_right(matrix: List[List[int]]) -> List[List[int]]:
    
    return
