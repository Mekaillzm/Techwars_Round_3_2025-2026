"""
Q29 (Python): Mutable default argument bug

Contract:
- This demonstrates the mutable default argument bug in Python.
- `add_student_buggy(name, student_list=[])` has the bug.
- `add_student_fixed(name, student_list=None)` is the correct version.
"""
from typing import List, Optional



def add_student_fixed(student_name: str, student_list: List[str] = None) -> List[str]:
    # TODO: Fix the mutable default argument bug

    student_list.append(student_name)
    return student_list
