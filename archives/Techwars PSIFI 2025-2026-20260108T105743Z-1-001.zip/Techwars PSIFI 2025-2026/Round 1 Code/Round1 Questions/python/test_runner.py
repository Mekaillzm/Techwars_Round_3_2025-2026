#!/usr/bin/env python3
import os
import sys
from typing import List


# Ensure local module imports work regardless of CWD
HERE = os.path.dirname(__file__)
if HERE not in sys.path:
    sys.path.insert(0, HERE)

# Easy questions (weightage: 3)
from easy.q1_pointers import swap_by_index, get_offset_value
from easy.q5_oop import BankAccount, SavingsAccount
from easy.q6_debugging_buggy import find_max, safe_divide
from easy.q8_calculator import add, subtract, multiply, integer_divide, real_divide, power, modulo
from easy.q10_statistics import calc_mean, calc_median, calc_range
from easy.q11_symbol_pattern import generate_symbol_pattern
from easy.q12_techwars_loop import techwars_sequence
from easy.q13_countdown import countdown
from easy.q14_vowel_counter import count_vowels
from easy.q15_percentage import calculate_percentage
from easy.q16_find_largest import find_largest
from easy.q17_leap_year import is_leap_year
from easy.q18_array_access import get_last_element
from easy.q19_temperature import fahrenheit_to_celsius, celsius_to_fahrenheit
from easy.q20_scope_bug import calculate_total
from easy.q21_even_sum import sum_of_evens
from easy.q22_logic_bug import is_yes

# Medium questions (weightage: 7)
from medium.q2_linkedlist import LinkedList
from medium.q4_procedural import transpose, rotate_right
from medium.q7_caeser_cipher import all_caesar_shifts
from medium.q23_palindrome import is_palindrome
from medium.q24_string_concat import create_introduction
from medium.q25_matrix_add import matrix_add
from medium.q26_student_class import Student
from medium.q27_bubble_sort import bubble_sort
from medium.q28_factorial import factorial
from medium.q29_default_arg_bug import add_student_buggy, add_student_fixed
from medium.q30_second_largest import find_second_largest

# Hard questions (weightage: 12)
from hard.q3_stack_queue import Stack, Queue
from hard.q9_binary_addition import binary_addition
from hard.q31_reverse_list import reverse_list, create_list, list_to_array
from hard.q32_binary_search import binary_search

GREEN = "\033[32m"
RED = "\033[31m"
YELLOW = "\033[33m"
RESET = "\033[0m"

# Weightage constants
EASY_WEIGHT = 3
MEDIUM_WEIGHT = 7
HARD_WEIGHT = 12

def ok_flag(cond: bool) -> str:
    return f"{GREEN}OK{RESET}" if cond else f"{RED}FAIL{RESET}"

def print_header(title: str, difficulty: str, weight: int):
    print("========================================")
    print(f"{title} [{difficulty} - {weight} pts] — detailed breakdown:")

def print_footer(passed: bool, weight: int):
    print("----------------------------------------")
    if passed:
        print(f"{GREEN}TOTAL: PASS ({weight}/{weight} pts){RESET}")
    else:
        print(f"{RED}TOTAL: FAIL (0/{weight} pts){RESET}")
    print("========================================")

# ==================== EASY QUESTIONS (3 pts each) ====================

def run_q1() -> int:
    swap_pts = offset_val_pts = offset_bounds_pts = 0
    swap_max, offset_val_max, offset_bounds_max = 1, 1, 1
    try:
        arr = [10, 20, 30, 40]
        swap_by_index(arr, 1, 3)
        if arr == [10, 40, 30, 20]:
            swap_pts = swap_max

        arr2 = [10, 40, 30, 20]
        v = get_offset_value(arr2, 0, 2)
        if v == 30:
            offset_val_pts = offset_val_max
        v2 = get_offset_value(arr2, 2, 2)
        if v2 is None:
            offset_bounds_pts = offset_bounds_max
    except Exception:
        pass

    total = swap_max + offset_val_max + offset_bounds_max
    score = swap_pts + offset_val_pts + offset_bounds_pts
    passed = (score == total)

    print_header('q1_pointers', 'EASY', EASY_WEIGHT)
    print(f"  swap_by_index             : {ok_flag(swap_pts==swap_max)}")
    print(f"  get_offset_value (value)  : {ok_flag(offset_val_pts==offset_val_max)}")
    print(f"  get_offset_value (bounds) : {ok_flag(offset_bounds_pts==offset_bounds_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q5() -> int:
    wd_ok_pts = wd_fail_pts = inherit_pts = 0
    wd_ok_max, wd_fail_max, inherit_max = 1, 1, 1
    try:
        ba = BankAccount(100.0)
        ba.deposit(50.0)
        ba.withdraw(30.0)
        if abs(ba.balance() - 120.0) < 0.01:
            wd_ok_pts = wd_ok_max
        try:
            ba.withdraw(500.0)
        except (ValueError, Exception):
            wd_fail_pts = wd_fail_max

        sa = SavingsAccount(200.0, 0.1)
        sa.apply_interest()
        if abs(sa.balance() - 220.0) < 0.01:
            inherit_pts = inherit_max
    except Exception:
        pass

    total = wd_ok_max + wd_fail_max + inherit_max
    score = wd_ok_pts + wd_fail_pts + inherit_pts
    passed = (score == total)

    print_header('q5_oop', 'EASY', EASY_WEIGHT)
    print(f"  withdraw success  : {ok_flag(wd_ok_pts==wd_ok_max)}")
    print(f"  withdraw fail     : {ok_flag(wd_fail_pts==wd_fail_max)}")
    print(f"  inheritance       : {ok_flag(inherit_pts==inherit_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q6() -> int:
    max_pts = div_ok_pts = div_zero_pts = 0
    max_max, div_ok_max, div_zero_max = 1, 1, 1
    try:
        nums = [3, 7, 2, 9, 4]
        if find_max(nums) == 9:
            max_pts = max_max
        res = safe_divide(10.0, 2.0)
        if abs(res - 5.0) < 0.01:
            div_ok_pts = div_ok_max
        try:
            safe_divide(5.0, 0.0)
        except (ZeroDivisionError, Exception):
            div_zero_pts = div_zero_max
    except Exception:
        pass

    total = max_max + div_ok_max + div_zero_max
    score = max_pts + div_ok_pts + div_zero_pts
    passed = (score == total)

    print_header('q6_debugging_buggy', 'EASY', EASY_WEIGHT)
    print(f"  find_max          : {ok_flag(max_pts==max_max)}")
    print(f"  safe_divide ok    : {ok_flag(div_ok_pts==div_ok_max)}")
    print(f"  safe_divide /0    : {ok_flag(div_zero_pts==div_zero_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q8() -> int:
    add_pts = sub_pts = mul_pts = idiv_pts = rdiv_pts = pow_pts = mod_pts = 0
    add_max = sub_max = mul_max = idiv_max = rdiv_max = pow_max = mod_max = 1
    try:
        if add(5, 3) == 8: add_pts = add_max
        if subtract(10, 4) == 6: sub_pts = sub_max
        if multiply(3, 7) == 21: mul_pts = mul_max
        if integer_divide(17, 5) == 3: idiv_pts = idiv_max
        if abs(real_divide(7.0, 2.0) - 3.5) < 0.01: rdiv_pts = rdiv_max
        if power(2, 10) == 1024: pow_pts = pow_max
        if modulo(17, 5) == 2: mod_pts = mod_max
    except Exception:
        pass

    total = add_max+sub_max+mul_max+idiv_max+rdiv_max+pow_max+mod_max
    score = add_pts+sub_pts+mul_pts+idiv_pts+rdiv_pts+pow_pts+mod_pts
    passed = (score == total)

    print_header('q8_calculator', 'EASY', EASY_WEIGHT)
    print(f"  add           : {ok_flag(add_pts==add_max)}")
    print(f"  subtract      : {ok_flag(sub_pts==sub_max)}")
    print(f"  multiply      : {ok_flag(mul_pts==mul_max)}")
    print(f"  integer_divide: {ok_flag(idiv_pts==idiv_max)}")
    print(f"  real_divide   : {ok_flag(rdiv_pts==rdiv_max)}")
    print(f"  power         : {ok_flag(pow_pts==pow_max)}")
    print(f"  modulo        : {ok_flag(mod_pts==mod_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q10() -> int:
    mean_pts = median_odd_pts = median_even_pts = range_pts = 0
    mean_max = median_odd_max = median_even_max = range_max = 1
    try:
        v1 = [1, 2, 3, 4, 5]
        if abs(calc_mean(v1) - 3.0) < 0.01: mean_pts = mean_max
        if abs(calc_median(v1) - 3.0) < 0.01: median_odd_pts = median_odd_max
        v2 = [1, 2, 3, 4]
        if abs(calc_median(v2) - 2.5) < 0.01: median_even_pts = median_even_max
        if calc_range(v1) == 4: range_pts = range_max
    except Exception:
        pass

    total = mean_max+median_odd_max+median_even_max+range_max
    score = mean_pts+median_odd_pts+median_even_pts+range_pts
    passed = (score == total)

    print_header('q10_statistics', 'EASY', EASY_WEIGHT)
    print(f"  mean          : {ok_flag(mean_pts==mean_max)}")
    print(f"  median (odd)  : {ok_flag(median_odd_pts==median_odd_max)}")
    print(f"  median (even) : {ok_flag(median_even_pts==median_even_max)}")
    print(f"  range         : {ok_flag(range_pts==range_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q11() -> int:
    simple_pts = mult5_pts = mult10_pts = 0
    simple_max = mult5_max = mult10_max = 1
    try:
        # generate_symbol_pattern(a, b) computes limit = larger/smaller, then for 1..limit:
        # '*' for multiples of 10, '#' for multiples of 5 (not 10), '-' otherwise
        s3 = generate_symbol_pattern(3, 1)  # limit=3: 1='-', 2='-', 3='-'
        if s3 == "---": simple_pts = simple_max
        s5 = generate_symbol_pattern(10, 2)  # limit=5: positions 1-4 are '-', position 5 is '#'
        if len(s5) == 5 and s5[4] == '#': mult5_pts = mult5_max
        s10 = generate_symbol_pattern(10, 1)  # limit=10: position 10 is '*'
        if len(s10) == 10 and s10[9] == '*': mult10_pts = mult10_max
    except Exception:
        pass

    total = simple_max+mult5_max+mult10_max
    score = simple_pts+mult5_pts+mult10_pts
    passed = (score == total)

    print_header('q11_symbol_pattern', 'EASY', EASY_WEIGHT)
    print(f"  simple pattern    : {ok_flag(simple_pts==simple_max)}")
    print(f"  mult of 5 (#)     : {ok_flag(mult5_pts==mult5_max)}")
    print(f"  mult of 10 (*)    : {ok_flag(mult10_pts==mult10_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q12() -> int:
    seq15_pts = tech_pts = wars_pts = techwars_pts = 0
    seq15_max = tech_max = wars_max = techwars_max = 1
    try:
        seq = techwars_sequence(15)
        if len(seq) == 15: seq15_pts = seq15_max
        if len(seq) >= 3 and seq[2] == "Tech": tech_pts = tech_max
        if len(seq) >= 5 and seq[4] == "Wars": wars_pts = wars_max
        if len(seq) >= 15 and seq[14] == "TechWars": techwars_pts = techwars_max
    except Exception:
        pass

    total = seq15_max+tech_max+wars_max+techwars_max
    score = seq15_pts+tech_pts+wars_pts+techwars_pts
    passed = (score == total)

    print_header('q12_techwars_loop', 'EASY', EASY_WEIGHT)
    print(f"  sequence length   : {ok_flag(seq15_pts==seq15_max)}")
    print(f"  Tech (mult of 3)  : {ok_flag(tech_pts==tech_max)}")
    print(f"  Wars (mult of 5)  : {ok_flag(wars_pts==wars_max)}")
    print(f"  TechWars (mult 15): {ok_flag(techwars_pts==techwars_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q13() -> int:
    len_pts = first_pts = last_pts = liftoff_pts = 0
    len_max = first_max = last_max = liftoff_max = 1
    try:
        seq = countdown(5)
        if len(seq) == 6: len_pts = len_max
        if len(seq) >= 1 and seq[0] == 5: first_pts = first_max
        if len(seq) >= 5 and seq[4] == 1: last_pts = last_max
        if len(seq) >= 6 and seq[5] == "Liftoff!": liftoff_pts = liftoff_max
    except Exception:
        pass

    total = len_max+first_max+last_max+liftoff_max
    score = len_pts+first_pts+last_pts+liftoff_pts
    passed = (score == total)

    print_header('q13_countdown', 'EASY', EASY_WEIGHT)
    print(f"  sequence length   : {ok_flag(len_pts==len_max)}")
    print(f"  first element (5) : {ok_flag(first_pts==first_max)}")
    print(f"  last number (1)   : {ok_flag(last_pts==last_max)}")
    print(f"  Liftoff! at end   : {ok_flag(liftoff_pts==liftoff_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q14() -> int:
    simple_pts = mixed_pts = empty_pts = 0
    simple_max = mixed_max = empty_max = 1
    try:
        if count_vowels("hello") == 2: simple_pts = simple_max
        if count_vowels("AEIOUaeiou") == 10: mixed_pts = mixed_max
        if count_vowels("xyz") == 0: empty_pts = empty_max
    except Exception:
        pass

    total = simple_max+mixed_max+empty_max
    score = simple_pts+mixed_pts+empty_pts
    passed = (score == total)

    print_header('q14_vowel_counter', 'EASY', EASY_WEIGHT)
    print(f"  simple string     : {ok_flag(simple_pts==simple_max)}")
    print(f"  mixed case vowels : {ok_flag(mixed_pts==mixed_max)}")
    print(f"  no vowels         : {ok_flag(empty_pts==empty_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q15() -> int:
    basic_pts = full_pts = 0
    basic_max = full_max = 1
    try:
        p1 = calculate_percentage(45, 50)
        if abs(p1 - 90.0) < 0.1: basic_pts = basic_max
        p2 = calculate_percentage(1, 3)
        if abs(p2 - 33.33) < 0.1: full_pts = full_max
    except Exception:
        pass

    total = basic_max+full_max
    score = basic_pts+full_pts
    passed = (score == total)

    print_header('q15_percentage', 'EASY', EASY_WEIGHT)
    print(f"  basic percentage  : {ok_flag(basic_pts==basic_max)}")
    print(f"  decimal percentage: {ok_flag(full_pts==full_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q16() -> int:
    pos_pts = neg_pts = single_pts = 0
    pos_max = neg_max = single_max = 1
    try:
        if find_largest([1, 5, 3, 9, 2]) == 9: pos_pts = pos_max
        if find_largest([-10, -5, -20]) == -5: neg_pts = neg_max
        if find_largest([42]) == 42: single_pts = single_max
    except Exception:
        pass

    total = pos_max+neg_max+single_max
    score = pos_pts+neg_pts+single_pts
    passed = (score == total)

    print_header('q16_find_largest', 'EASY', EASY_WEIGHT)
    print(f"  positive numbers  : {ok_flag(pos_pts==pos_max)}")
    print(f"  negative numbers  : {ok_flag(neg_pts==neg_max)}")
    print(f"  single element    : {ok_flag(single_pts==single_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q17() -> int:
    leap_pts = century_pts = quad_century_pts = non_leap_pts = 0
    leap_max = century_max = quad_century_max = non_leap_max = 1
    try:
        if is_leap_year(2024): leap_pts = leap_max
        if not is_leap_year(1900): century_pts = century_max
        if is_leap_year(2000): quad_century_pts = quad_century_max
        if not is_leap_year(2023): non_leap_pts = non_leap_max
    except Exception:
        pass

    total = leap_max+century_max+quad_century_max+non_leap_max
    score = leap_pts+century_pts+quad_century_pts+non_leap_pts
    passed = (score == total)

    print_header('q17_leap_year', 'EASY', EASY_WEIGHT)
    print(f"  regular leap year : {ok_flag(leap_pts==leap_max)}")
    print(f"  century non-leap  : {ok_flag(century_pts==century_max)}")
    print(f"  400-year leap     : {ok_flag(quad_century_pts==quad_century_max)}")
    print(f"  regular non-leap  : {ok_flag(non_leap_pts==non_leap_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q18() -> int:
    correct_pts = 0
    correct_max = 1
    try:
        arr = [10, 20, 30, 40, 50]
        if get_last_element(arr) == 50: correct_pts = correct_max
    except Exception:
        pass

    total = correct_max
    score = correct_pts
    passed = (score == total)

    print_header('q18_array_access', 'EASY', EASY_WEIGHT)
    print(f"  get last element  : {ok_flag(correct_pts==correct_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q19() -> int:
    f_to_c_pts = c_to_f_pts = freeze_pts = 0
    f_to_c_max = c_to_f_max = freeze_max = 1
    try:
        if abs(fahrenheit_to_celsius(212.0) - 100.0) < 0.1: f_to_c_pts = f_to_c_max
        if abs(celsius_to_fahrenheit(100.0) - 212.0) < 0.1: c_to_f_pts = c_to_f_max
        if abs(fahrenheit_to_celsius(32.0) - 0.0) < 0.1: freeze_pts = freeze_max
    except Exception:
        pass

    total = f_to_c_max+c_to_f_max+freeze_max
    score = f_to_c_pts+c_to_f_pts+freeze_pts
    passed = (score == total)

    print_header('q19_temperature', 'EASY', EASY_WEIGHT)
    print(f"  F to C (boiling)  : {ok_flag(f_to_c_pts==f_to_c_max)}")
    print(f"  C to F (boiling)  : {ok_flag(c_to_f_pts==c_to_f_max)}")
    print(f"  F to C (freezing) : {ok_flag(freeze_pts==freeze_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q20() -> int:
    calc_pts = 0
    calc_max = 1
    try:
        if calculate_total(False, 100, 50) == 0: calc_pts = calc_max
    except Exception:
        pass

    total = calc_max
    score = calc_pts
    passed = (score == total)

    print_header('q20_scope_bug', 'EASY', EASY_WEIGHT)
    print(f"  calculate total   : {ok_flag(calc_pts==calc_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q21() -> int:
    small_pts = ten_pts = odd_pts = 0
    small_max = ten_max = odd_max = 1
    try:
        if sum_of_evens(6) == 12: small_pts = small_max
        if sum_of_evens(10) == 30: ten_pts = ten_max
        if sum_of_evens(7) == 12: odd_pts = odd_max
    except Exception:
        pass

    total = small_max+ten_max+odd_max
    score = small_pts+ten_pts+odd_pts
    passed = (score == total)

    print_header('q21_even_sum', 'EASY', EASY_WEIGHT)
    print(f"  sum to 6          : {ok_flag(small_pts==small_max)}")
    print(f"  sum to 10         : {ok_flag(ten_pts==ten_max)}")
    print(f"  sum to 7 (odd n)  : {ok_flag(odd_pts==odd_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

def run_q22() -> int:
    lower_pts = upper_pts = other_pts = 0
    lower_max = upper_max = other_max = 1
    try:
        if is_yes('y'): lower_pts = lower_max
        if is_yes('Y'): upper_pts = upper_max
        if not is_yes('n'): other_pts = other_max
    except Exception:
        pass

    total = lower_max+upper_max+other_max
    score = lower_pts+upper_pts+other_pts
    passed = (score == total)

    print_header('q22_logic_bug', 'EASY', EASY_WEIGHT)
    print(f"  lowercase 'y'     : {ok_flag(lower_pts==lower_max)}")
    print(f"  uppercase 'Y'     : {ok_flag(upper_pts==upper_max)}")
    print(f"  other char 'n'    : {ok_flag(other_pts==other_max)}")
    print_footer(passed, EASY_WEIGHT)
    return EASY_WEIGHT if passed else 0

# ==================== MEDIUM QUESTIONS (7 pts each) ====================

def run_q2() -> int:
    head_pts = tail_pts = tovec_pts = del_pts = 0
    head_max = tail_max = tovec_max = del_max = 1
    try:
        ll = LinkedList()
        ll.insert_at_head(10)
        ll.insert_at_head(20)
        head_pts = head_max

        ll.insert_at_tail(5)
        tail_pts = tail_max

        v = ll.to_list()
        if v == [20, 10, 5]:
            tovec_pts = tovec_max

        ll.delete_value(10)
        v2 = ll.to_list()
        if v2 == [20, 5]:
            del_pts = del_max
    except Exception:
        pass

    total = head_max+tail_max+tovec_max+del_max
    score = head_pts+tail_pts+tovec_pts+del_pts
    passed = (score == total)

    print_header('q2_linkedlist', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  insert_at_head    : {ok_flag(head_pts==head_max)}")
    print(f"  insert_at_tail    : {ok_flag(tail_pts==tail_max)}")
    print(f"  to_list           : {ok_flag(tovec_pts==tovec_max)}")
    print(f"  delete_value      : {ok_flag(del_pts==del_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q4() -> int:
    trans_pts = rotate_pts = 0
    trans_max = rotate_max = 1
    try:
        mat = [[1,2,3],[4,5,6]]
        t = transpose(mat)
        if t == [[1,4],[2,5],[3,6]]:
            trans_pts = trans_max

        sq = [[1,2],[3,4]]
        r = rotate_right(sq)
        if r == [[3,1],[4,2]]:
            rotate_pts = rotate_max
    except Exception:
        pass

    total = trans_max+rotate_max
    score = trans_pts+rotate_pts
    passed = (score == total)

    print_header('q4_procedural', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  transpose         : {ok_flag(trans_pts==trans_max)}")
    print(f"  rotate_right      : {ok_flag(rotate_pts==rotate_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q7() -> int:
    has_orig_pts = shift13_pts = 0
    has_orig_max = shift13_max = 1
    try:
        plain = "abc"
        shifts = all_caesar_shifts(plain)
        if len(shifts) == 26 and shifts[0] == plain:
            has_orig_pts = has_orig_max
        if len(shifts) >= 14 and shifts[13] == "nop":
            shift13_pts = shift13_max
    except Exception:
        pass

    total = has_orig_max+shift13_max
    score = has_orig_pts+shift13_pts
    passed = (score == total)

    print_header('q7_caeser_cipher', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  has original      : {ok_flag(has_orig_pts==has_orig_max)}")
    print(f"  shift 13 (ROT13)  : {ok_flag(shift13_pts==shift13_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q23() -> int:
    simple_pts = phrase_pts = non_pts = 0
    simple_max = phrase_max = non_max = 1
    try:
        if is_palindrome("racecar"): simple_pts = simple_max
        if is_palindrome("A man a plan a canal Panama"): phrase_pts = phrase_max
        if not is_palindrome("hello"): non_pts = non_max
    except Exception:
        pass

    total = simple_max+phrase_max+non_max
    score = simple_pts+phrase_pts+non_pts
    passed = (score == total)

    print_header('q23_palindrome', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  simple palindrome : {ok_flag(simple_pts==simple_max)}")
    print(f"  phrase palindrome : {ok_flag(phrase_pts==phrase_max)}")
    print(f"  non-palindrome    : {ok_flag(non_pts==non_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q24() -> int:
    intro_pts = 0
    intro_max = 1
    try:
        result = create_introduction("Ahmed", 17)
        if result == "My name is Ahmed and I am 17 years old.":
            intro_pts = intro_max
    except Exception:
        pass

    total = intro_max
    score = intro_pts
    passed = (score == total)

    print_header('q24_string_concat', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  create intro      : {ok_flag(intro_pts==intro_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q25() -> int:
    add_2x2_pts = add_3x3_pts = 0
    add_2x2_max = add_3x3_max = 1
    try:
        a = [[1,2],[3,4]]
        b = [[5,6],[7,8]]
        expected = [[6,8],[10,12]]
        if matrix_add(a, b) == expected: add_2x2_pts = add_2x2_max

        c = [[1,1,1],[2,2,2],[3,3,3]]
        d = [[1,0,0],[0,1,0],[0,0,1]]
        exp2 = [[2,1,1],[2,3,2],[3,3,4]]
        if matrix_add(c, d) == exp2: add_3x3_pts = add_3x3_max
    except Exception:
        pass

    total = add_2x2_max+add_3x3_max
    score = add_2x2_pts+add_3x3_pts
    passed = (score == total)

    print_header('q25_matrix_add', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  2x2 matrix add    : {ok_flag(add_2x2_pts==add_2x2_max)}")
    print(f"  3x3 matrix add    : {ok_flag(add_3x3_pts==add_3x3_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q26() -> int:
    name_pts = gpa_pts = honors_yes_pts = honors_no_pts = 0
    name_max = gpa_max = honors_yes_max = honors_no_max = 1
    try:
        s1 = Student("Ali", 123, 3.8)
        if s1.get_name() == "Ali": name_pts = name_max
        if abs(s1.get_gpa() - 3.8) < 0.01: gpa_pts = gpa_max
        if s1.is_honors(): honors_yes_pts = honors_yes_max

        s2 = Student("Bob", 456, 3.0)
        if not s2.is_honors(): honors_no_pts = honors_no_max
    except Exception:
        pass

    total = name_max+gpa_max+honors_yes_max+honors_no_max
    score = name_pts+gpa_pts+honors_yes_pts+honors_no_pts
    passed = (score == total)

    print_header('q26_student_class', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  get name          : {ok_flag(name_pts==name_max)}")
    print(f"  get gpa           : {ok_flag(gpa_pts==gpa_max)}")
    print(f"  honors (yes)      : {ok_flag(honors_yes_pts==honors_yes_max)}")
    print(f"  honors (no)       : {ok_flag(honors_no_pts==honors_no_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q27() -> int:
    asc_pts = 0
    asc_max = 1
    try:
        arr = [64, 34, 25, 12, 22, 11, 90]
        bubble_sort(arr)
        if arr == [11, 12, 22, 25, 34, 64, 90]: asc_pts = asc_max
    except Exception:
        pass

    total = asc_max
    score = asc_pts
    passed = (score == total)

    print_header('q27_bubble_sort', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  ascending sort    : {ok_flag(asc_pts==asc_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q28() -> int:
    zero_pts = five_pts = neg_pts = 0
    zero_max = five_max = neg_max = 1
    try:
        if factorial(0) == 1: zero_pts = zero_max
        if factorial(5) == 120: five_pts = five_max
        if factorial(-1) == -1: neg_pts = neg_max
    except Exception:
        pass

    total = zero_max+five_max+neg_max
    score = zero_pts+five_pts+neg_pts
    passed = (score == total)

    print_header('q28_factorial', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  factorial(0)      : {ok_flag(zero_pts==zero_max)}")
    print(f"  factorial(5)      : {ok_flag(five_pts==five_max)}")
    print(f"  factorial(-1)     : {ok_flag(neg_pts==neg_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q29() -> int:
    fixed_pts = 0
    fixed_max = 1
    try:
        list1 = add_student_fixed("Ali", None)
        list2 = add_student_fixed("Sara", None)
        if len(list1) == 1 and len(list2) == 1 and list1[0] == "Ali" and list2[0] == "Sara":
            fixed_pts = fixed_max
    except Exception:
        pass

    total = fixed_max
    score = fixed_pts
    passed = (score == total)

    print_header('q29_default_arg_bug', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  fixed version     : {ok_flag(fixed_pts==fixed_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

def run_q30() -> int:
    basic_pts = dup_pts = 0
    basic_max = dup_max = 1
    try:
        if find_second_largest([234, 49, 54, 67, 344, 67]) == 234: basic_pts = basic_max
        if find_second_largest([5, 5, 5, 3, 3]) == 3: dup_pts = dup_max
    except Exception:
        pass

    total = basic_max+dup_max
    score = basic_pts+dup_pts
    passed = (score == total)

    print_header('q30_second_largest', 'MEDIUM', MEDIUM_WEIGHT)
    print(f"  basic case        : {ok_flag(basic_pts==basic_max)}")
    print(f"  with duplicates   : {ok_flag(dup_pts==dup_max)}")
    print_footer(passed, MEDIUM_WEIGHT)
    return MEDIUM_WEIGHT if passed else 0

# ==================== HARD QUESTIONS (12 pts each) ====================

def run_q3() -> int:
    push_pts = pop_pts = enq_pts = deq_pts = 0
    push_max = pop_max = enq_max = deq_max = 1
    try:
        s = Stack()
        s.push(1); s.push(2); s.push(3)
        if s.pop() == 3 and s.pop() == 2:
            pop_pts = pop_max
        push_pts = push_max

        q = Queue()
        q.enqueue(1); q.enqueue(2); q.enqueue(3)
        if q.dequeue() == 1 and q.dequeue() == 2:
            deq_pts = deq_max
        enq_pts = enq_max
    except Exception:
        pass

    total = push_max+pop_max+enq_max+deq_max
    score = push_pts+pop_pts+enq_pts+deq_pts
    passed = (score == total)

    print_header('q3_stack_queue', 'HARD', HARD_WEIGHT)
    print(f"  stack push        : {ok_flag(push_pts==push_max)}")
    print(f"  stack pop         : {ok_flag(pop_pts==pop_max)}")
    print(f"  queue enqueue     : {ok_flag(enq_pts==enq_max)}")
    print(f"  queue dequeue     : {ok_flag(deq_pts==deq_max)}")
    print_footer(passed, HARD_WEIGHT)
    return HARD_WEIGHT if passed else 0

def run_q9() -> int:
    simple_pts = carry_pts = diff_len_pts = 0
    simple_max = carry_max = diff_len_max = 1
    try:
        if binary_addition("101", "110") == "1011": simple_pts = simple_max
        if binary_addition("111", "1") == "1000": carry_pts = carry_max
        if binary_addition("1", "1111") == "10000": diff_len_pts = diff_len_max
    except Exception:
        pass

    total = simple_max+carry_max+diff_len_max
    score = simple_pts+carry_pts+diff_len_pts
    passed = (score == total)

    print_header('q9_binary_addition', 'HARD', HARD_WEIGHT)
    print(f"  simple addition   : {ok_flag(simple_pts==simple_max)}")
    print(f"  with carry        : {ok_flag(carry_pts==carry_max)}")
    print(f"  different lengths : {ok_flag(diff_len_pts==diff_len_max)}")
    print_footer(passed, HARD_WEIGHT)
    return HARD_WEIGHT if passed else 0

def run_q31() -> int:
    reverse_pts = 0
    reverse_max = 1
    try:
        head = create_list([1, 2, 3, 4, 5])
        reversed_head = reverse_list(head)
        result = list_to_array(reversed_head)
        if result == [5, 4, 3, 2, 1]: reverse_pts = reverse_max
    except Exception:
        pass

    total = reverse_max
    score = reverse_pts
    passed = (score == total)

    print_header('q31_reverse_list', 'HARD', HARD_WEIGHT)
    print(f"  reverse list      : {ok_flag(reverse_pts==reverse_max)}")
    print_footer(passed, HARD_WEIGHT)
    return HARD_WEIGHT if passed else 0

def run_q32() -> int:
    found_pts = not_found_pts = 0
    found_max = not_found_max = 1
    try:
        arr = [2, 5, 8, 12, 16, 23, 38, 56, 72, 91]
        if binary_search(arr, 16) == 4: found_pts = found_max
        if binary_search(arr, 100) == -1: not_found_pts = not_found_max
    except Exception:
        pass

    total = found_max+not_found_max
    score = found_pts+not_found_pts
    passed = (score == total)

    print_header('q32_binary_search', 'HARD', HARD_WEIGHT)
    print(f"  element found     : {ok_flag(found_pts==found_max)}")
    print(f"  element not found : {ok_flag(not_found_pts==not_found_max)}")
    print_footer(passed, HARD_WEIGHT)
    return HARD_WEIGHT if passed else 0

# ==================== RUN ALL ====================

def run_all():
    easy_score = 0
    medium_score = 0
    hard_score = 0
    max_score = 17 * EASY_WEIGHT + 11 * MEDIUM_WEIGHT + 4 * HARD_WEIGHT  # 51 + 77 + 48 = 176

    print(f"\n{YELLOW}===== RUNNING ALL TESTS ====={RESET}\n")

    # Easy questions (17 questions × 3 pts = 51 pts)
    easy_score += run_q1()
    easy_score += run_q5()
    easy_score += run_q6()
    easy_score += run_q8()
    easy_score += run_q10()
    easy_score += run_q11()
    easy_score += run_q12()
    easy_score += run_q13()
    easy_score += run_q14()
    easy_score += run_q15()
    easy_score += run_q16()
    easy_score += run_q17()
    easy_score += run_q18()
    easy_score += run_q19()
    easy_score += run_q20()
    easy_score += run_q21()
    easy_score += run_q22()

    # Medium questions (11 questions × 7 pts = 77 pts)
    medium_score += run_q2()
    medium_score += run_q4()
    medium_score += run_q7()
    medium_score += run_q23()
    medium_score += run_q24()
    medium_score += run_q25()
    medium_score += run_q26()
    medium_score += run_q27()
    medium_score += run_q28()
    medium_score += run_q29()
    medium_score += run_q30()

    # Hard questions (4 questions × 12 pts = 48 pts)
    hard_score += run_q3()
    hard_score += run_q9()
    hard_score += run_q31()
    hard_score += run_q32()

    total_score = easy_score + medium_score + hard_score

    print(f"\n{YELLOW}===== FINAL SCORE ====={RESET}")
    print(f"Easy   (17 × 3 pts): {easy_score}/51")
    print(f"Medium (11 × 7 pts): {medium_score}/77")
    print(f"Hard   ( 4 × 12 pts): {hard_score}/48")
    print("----------------------------------------")
    if total_score == max_score:
        print(f"{GREEN}GRAND TOTAL: {total_score}/{max_score} pts - PERFECT SCORE!{RESET}")
    else:
        print(f"{YELLOW}GRAND TOTAL: {total_score}/{max_score} pts{RESET}")

def main(argv: List[str]):
    runners = [
        run_q1, run_q2, run_q3, run_q4, run_q5, run_q6, run_q7,
        run_q8, run_q9, run_q10, run_q11, run_q12, run_q13, run_q14,
        run_q15, run_q16, run_q17, run_q18, run_q19, run_q20, run_q21,
        run_q22, run_q23, run_q24, run_q25, run_q26, run_q27, run_q28,
        run_q29, run_q30, run_q31, run_q32
    ]

    if len(argv) > 1:
        arg = argv[1]
        if arg in ("all", "34"):
            run_all(); return
        if arg == "0":
            return
        try:
            n = int(arg)
            if 1 <= n <= 33:
                runners[n-1]()
                return
        except Exception:
            pass

    while True:
        print("\nSelect a test to run (or 0 to exit, 34 to run all, q to quit):")
        print("=== EASY (3 pts each) ===")
        print(" 1) q1_pointers         12) q12_techwars_loop   19) q19_temperature")
        print(" 5) q5_oop              13) q13_countdown       20) q20_scope_bug")
        print(" 6) q6_debugging        14) q14_vowel_counter   21) q21_even_sum")
        print(" 8) q8_calculator       15) q15_percentage      22) q22_logic_bug")
        print("10) q10_statistics      16) q16_find_largest")
        print("11) q11_symbol_pattern  17) q17_leap_year")
        print("                        18) q18_array_access")
        print("\n=== MEDIUM (7 pts each) ===")
        print(" 2) q2_linkedlist       23) q23_palindrome      27) q27_bubble_sort")
        print(" 4) q4_procedural       24) q24_string_concat   28) q28_factorial")
        print(" 7) q7_caeser_cipher    25) q25_matrix_add      29) q29_default_arg_bug")
        print("                        26) q26_student_class   30) q30_second_largest")
        print("\n=== HARD (12 pts each) ===")
        print(" 3) q3_stack_queue       9) q9_binary_addition  31) q31_reverse_list")
        print("32) q32_binary_search")
        print("\n34) run all tests")
        print(" 0) exit\n")
        line = input("Enter choice: ").strip()
        if line.lower() == 'q':
            break
        if line == '0':
            break
        if line == '34' or line == 'all':
            run_all(); continue
        try:
            choice = int(line)
            if 1 <= choice <= 33:
                runners[choice-1]()
            else:
                print("Invalid choice")
        except Exception:
            print("Invalid input")

if __name__ == '__main__':
    main(sys.argv)
