
"""
Q31 (Python): Reverse a singly linked list

Contract:
- Implement a Node class and `reverse_list(head)` function.
- Reverse by manipulating pointers, not by creating a new list with reversed values.
"""
from typing import Optional, List


class ListNode:
    def __init__(self, val: int):
        self.val = val
        self.next: Optional['ListNode'] = None


def reverse_list(head: Optional[ListNode]) -> Optional[ListNode]:
    # TODO: Reverse the linked list by manipulating pointers
    
    return head


def create_list(arr: List[int]) -> Optional[ListNode]:
    """Helper to create list from array (for testing)"""
    if not arr:
        return None
    head = ListNode(arr[0])
    curr = head
    for val in arr[1:]:
        curr.next = ListNode(val)
        curr = curr.next
    return head


def list_to_array(head: Optional[ListNode]) -> List[int]:
    """Helper to convert list to array (for testing)"""
    result = []
    while head:
        result.append(head.val)
        head = head.next
    return result
