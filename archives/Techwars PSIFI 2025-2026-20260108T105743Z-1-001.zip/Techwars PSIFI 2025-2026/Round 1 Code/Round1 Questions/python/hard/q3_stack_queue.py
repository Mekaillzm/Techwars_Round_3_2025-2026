"""
Q3 (Python): Implement data structures.

Contract:
- Implement `Stack` with push/pop/peek/is_empty.
- Implement `Queue` with enqueue/dequeue/peek/is_empty.
- Provide `stack_using_queues` and `queue_using_stacks` wrappers (student can choose any strategy).
"""
from typing import List, Any


class Stack:
    def __init__(self):
        self._data: List[Any] = []

    def push(self, x: Any) -> None:
        
        return

    def pop(self) -> Any:
       
        return

    def peek(self) -> Any:
        
        return

    def is_empty(self) -> bool:
        return len(self._data) == 0


class Queue:
    def __init__(self):
        self._data: List[Any] = []

    def enqueue(self, x: Any) -> None:
        
        return

    def dequeue(self) -> Any:
        
        return

    def peek(self) -> Any:
        
        return

    def is_empty(self) -> bool:
        return len(self._data) == 0


# optional

def stack_using_queues():
    
    return


def queue_using_stacks():
    
    return
