"""
Q32 (Python): Binary search debugging exercise

Contract:
- Implement `binary_search(arr, target)` that returns index of target, or -1 if not found.
- This is a debugging exercise - the buggy version can infinite loop.
"""
from typing import List


def binary_search(arr: List[int], target: int) -> int:
    
    
    low = 0
    high = len(arr) - 1
    
    while low <= high:
        mid = (low + high) // 2
        
        if arr[mid] == target:
            return mid
        elif arr[mid] < target:
            low = mid  
        else:
            high = mid - 1
    
    return -1
