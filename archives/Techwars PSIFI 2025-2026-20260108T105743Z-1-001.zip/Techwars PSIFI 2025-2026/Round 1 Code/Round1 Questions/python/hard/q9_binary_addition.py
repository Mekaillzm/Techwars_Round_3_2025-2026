"""
Q9 (Python): Binary addition of two binary strings.

Contract:
- Implement `binary_addition(x, y)` which takes two binary strings of equal length.
- Returns the sum as a binary string (may be one bit longer due to carry).
- Example: binary_addition("011", "001") returns "100"
"""


def binary_addition(x: str, y: str) -> str:
    # TODO: Implement binary addition of two binary strings
    # Handle carry properly
    
    result = ""
    
    return result
