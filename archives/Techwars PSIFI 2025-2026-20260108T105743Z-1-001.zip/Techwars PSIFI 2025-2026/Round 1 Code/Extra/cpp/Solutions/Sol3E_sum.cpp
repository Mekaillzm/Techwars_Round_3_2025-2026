// GOAL: Sum all integers from 1 to n.
int sum_to_n(int n) {
    int total = 0;
    // FIX: i <= n
    for (int i = 1; i <= n; i++) { 
        total += i;
    }
    return total;
}