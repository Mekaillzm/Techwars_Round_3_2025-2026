// GOAL: Calculate area of a triangle.
float triangle_area(int base, int height) {
    float area = 0.5f * base * height; 
    return area;
}