#include <vector>
// GOAL: Sum the main diagonal.
int diagonal_sum(std::vector<std::vector<int>> matrix) {
    int sum = 0;
    for (int i = 0; i < matrix.size(); i++) {
        sum += matrix[i][i];
    }
    return sum;
}