// GOAL: Return true if age is 18 or older.
bool can_vote(int age) {
    if (age >= 18) { 
        return true;
    }
    return false;
}