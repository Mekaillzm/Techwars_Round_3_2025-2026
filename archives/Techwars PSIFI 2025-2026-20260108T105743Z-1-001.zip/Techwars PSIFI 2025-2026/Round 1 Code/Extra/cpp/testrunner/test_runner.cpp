// g++ test_runner.cpp Q1E_triangle.cpp Q2E_evencount.cpp Q3E_sum.cpp Q1M_replace.cpp Q2M_Linearsearch.cpp Q1H_diagsum.cpp -o run_tests
#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <algorithm>

// --- ANSI Colors for PASS/FAIL ---
static const char* GREEN = "\033[32m";
static const char* RED = "\033[31m";
static const char* RESET = "\033[0m";

// --- Forward Declarations (EXACTLY matching your files) ---
float triangle_area(int base, int height);                  // From Q1E_triangle.cpp
bool can_vote(int age);                                     // From Q2E_evencount.cpp
int sum_to_n(int n);                                        // From Q3E_sum.cpp
void replace_char(std::string &s, char target, char repl);  // From Q1M_replace.cpp
int find_index(std::vector<int> arr, int target);           // From Q2M_Linearsearch.cpp
int diagonal_sum(std::vector<std::vector<int>> matrix);     // From Q1H_diagsum.cpp

// --- Helper Functions ---
void print_header(const std::string &title) {
    std::cout << "\n========================================\n";
    std::cout << title << " — detailed breakdown:\n";
}

void print_footer(int score, int total) {
    std::cout << "----------------------------------------\n";
    if (score == total) std::cout << GREEN << "TOTAL: PASS (" << score << "/" << total << ")" << RESET << "\n";
    else std::cout << RED << "TOTAL: FAIL (" << score << "/" << total << ")" << RESET << "\n";
    std::cout << "========================================\n";
}

std::string ok_flag(bool cond) {
    return cond ? std::string(GREEN) + "PASS" + RESET : std::string(RED) + "FAIL" + RESET;
}

// --- Test Cases ---

void run_q1e() { 
    int val_pts = 0;
    try {
        // Bug: (1/2) * base * height causes integer division 0
        if (std::abs(triangle_area(10, 5) - 25.0f) < 0.1f) val_pts = 5;
    } catch (...) {}

    print_header("Q1E: Triangle Area (Q1E_triangle.cpp)");
    std::cout << "  Area(10, 5) -> 25.0 : " << val_pts << "/5 " << ok_flag(val_pts==5) << "\n";
    print_footer(val_pts, 5);
}

void run_q2e() { 
    int pts = 0;
    try {
        // Bug: Might have incorrect boundary condition
        if (can_vote(18) == true && can_vote(17) == false) pts = 5;
    } catch (...) {}

    print_header("Q2E: Vote Check (Q2E_evencount.cpp)");
    std::cout << "  Age 18 (True), 17 (False) : " << pts << "/5 " << ok_flag(pts==5) << "\n";
    print_footer(pts, 5);
}

void run_q3e() { 
    int pts = 0;
    try {
        // Bug: Loop uses < n instead of <= n
        if (sum_to_n(5) == 15) pts = 5;
    } catch (...) {}

    print_header("Q3E: Sum 1 to N (Q3E_sum.cpp)");
    std::cout << "  Sum(5) -> 15 : " << pts << "/5 " << ok_flag(pts==5) << "\n";
    print_footer(pts, 5);
}

void run_q1m() { 
    int pts = 0;
    try {
        std::string s = "banana";
        // Bug: replace_char logic is backwards
        replace_char(s, 'a', 'o');
        if (s == "bonono") pts = 5;
    } catch (...) {}

    print_header("Q1M: Replace Char (Q1M_replace.cpp)");
    std::cout << "  'banana' -> 'bonono' : " << pts << "/5 " << ok_flag(pts==5) << "\n";
    print_footer(pts, 5);
}

void run_q2m() { 
    int pts = 0;
    try {
        // Bug: Returns -1 immediately if first element isn't target
        std::vector<int> v = {10, 20, 30};
        if (find_index(v, 30) == 2) pts = 5;
    } catch (...) {}

    print_header("Q2M: Linear Search (Q2M_Linearsearch.cpp)");
    std::cout << "  Find index of 30 in {10,20,30} : " << pts << "/5 " << ok_flag(pts==5) << "\n";
    print_footer(pts, 5);
}

void run_q1h() { 
    int pts = 0;
    try {
        // Bug: Inner loop sums entire row because (i==i) is always true
        std::vector<std::vector<int>> mat = {{1, 2}, {3, 4}};
        if (diagonal_sum(mat) == 5) pts = 5;
    } catch (...) {}

    print_header("Q1H: Diagonal Sum (Q1H_diagsum.cpp)");
    std::cout << "  {{1,2},{3,4}} -> 5 : " << pts << "/5 " << ok_flag(pts==5) << "\n";
    print_footer(pts, 5);
}

void run_all() {
    run_q1e(); run_q2e(); run_q3e();
    run_q1m(); run_q2m(); run_q1h();
}

int main() {
    while (true) {
        std::cout << "\n--- C++ Debugging Test Runner ---\n";
        std::cout << " 1) Q1E_triangle.cpp\n";
        std::cout << " 2) Q2E_evencount.cpp\n";
        std::cout << " 3) Q3E_sum.cpp\n";
        std::cout << " 4) Q1M_replace.cpp\n";
        std::cout << " 5) Q2M_Linearsearch.cpp\n";
        std::cout << " 6) Q1H_diagsum.cpp\n";
        std::cout << " 8) Run All Tests\n";
        std::cout << " 0) Exit\n";
        std::cout << "Enter choice: ";
        
        std::string line;
        if (!std::getline(std::cin, line)) break;
        if (line == "0") break;
        if (line == "8") { run_all(); continue; }
        
        try {
            int choice = std::stoi(line);
            switch(choice) {
                case 1: run_q1e(); break;
                case 2: run_q2e(); break;
                case 3: run_q3e(); break;
                case 4: run_q1m(); break;
                case 5: run_q2m(); break;
                case 6: run_q1h(); break;
                default: std::cout << "Invalid choice\n";
            }
        } catch(...) { std::cout << "Invalid input\n"; }
    }
    return 0;
}