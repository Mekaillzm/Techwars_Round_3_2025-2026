#include <string>
// GOAL: Replace all occurrences of target char with replacement char.
void replace_char(std::string &s, char target, char replacement) {
    for (int i = 0; i < s.length(); i++) {
        if (s[i] == target) {
            replacement = s[i];
        }
    }
}