// GOAL: Calculate area of a triangle (0.5 * base * height).
float triangle_area(int base, int height) {
    float area = (1 / 2) * base * height; 
    return area;
}