#include <vector>
// GOAL: Sum numbers where row index equals column index (0,0), (1,1)...
int diagonal_sum(std::vector<std::vector<int>> matrix) {
    int sum = 0;
    for (int i = 0; i < matrix.size(); i++) {
        for (int j = 0; j < matrix[i].size(); j++) { 
            if (i == i) { 
                sum += matrix[i][j]; 
            }
        }
    }
    return sum;
}