// GOAL: Sum all integers from 1 to n.
// BUG: Loop starts at 0 and uses < n, missing the last number 'n'.
int sum_to_n(int n) {
    int total = 0;
    for (int i = 0; i < n; i++) { // FIX: i <= n
        total += i;
    }
    return total;
}