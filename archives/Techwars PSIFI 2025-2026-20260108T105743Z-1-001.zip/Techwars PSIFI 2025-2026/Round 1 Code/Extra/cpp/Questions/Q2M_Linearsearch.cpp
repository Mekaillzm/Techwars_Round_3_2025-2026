#include <vector>
// GOAL: Return the index of 'target'. Return -1 if not found.
// BUG: Returns -1 immediately if the FIRST element isn't the target.
int find_index(std::vector<int> arr, int target) {
    for (int i = 0; i < arr.size(); i++) {
        if (arr[i] == target) {
            return i;
        } else {
            return -1; // FIX: Remove this else block.
        }
    }
    return -1;
}