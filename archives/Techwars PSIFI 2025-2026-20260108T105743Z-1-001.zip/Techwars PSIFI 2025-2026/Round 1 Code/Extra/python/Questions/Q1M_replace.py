# GOAL: Replace all occurrences of target char with replacement char.
def replace_char(s, target, replacement):
    s_list = list(s)
    for i in range(len(s_list)):
        if s_list[i] == target:
            replacement = s_list[i] 
    return "".join(s_list)