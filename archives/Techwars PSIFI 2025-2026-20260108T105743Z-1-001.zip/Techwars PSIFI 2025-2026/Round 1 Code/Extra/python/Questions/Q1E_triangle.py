# GOAL: Calculate area of a triangle (0.5 * base * height).
def triangle_area(base, height):
    area = (1 // 2) * base * height 
    return area