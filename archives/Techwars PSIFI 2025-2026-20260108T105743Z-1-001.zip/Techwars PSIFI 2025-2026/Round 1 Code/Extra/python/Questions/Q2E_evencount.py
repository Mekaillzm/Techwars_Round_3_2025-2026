# GOAL: Return true if age is 18 or older.
def can_vote(age):
    if age >= 18:
        return True
    return False