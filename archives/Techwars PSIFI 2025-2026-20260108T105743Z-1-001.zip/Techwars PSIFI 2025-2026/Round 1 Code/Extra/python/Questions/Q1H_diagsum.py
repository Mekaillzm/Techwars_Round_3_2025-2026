# GOAL: Sum numbers where row index equals column index (0,0), (1,1)...
def diagonal_sum(matrix):
    total = 0
    for i in range(len(matrix)):
        for j in range(len(matrix[i])):
            if i == i: 
                total += matrix[i][j]
    return total