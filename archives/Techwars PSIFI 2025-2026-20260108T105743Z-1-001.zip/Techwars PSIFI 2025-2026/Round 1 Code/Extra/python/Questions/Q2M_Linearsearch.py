# GOAL: Return the index of 'target'. Return -1 if not found.
def find_index(arr, target):
    for i in range(len(arr)):
        if arr[i] == target:
            return i
        else:
            return -1
    return -1