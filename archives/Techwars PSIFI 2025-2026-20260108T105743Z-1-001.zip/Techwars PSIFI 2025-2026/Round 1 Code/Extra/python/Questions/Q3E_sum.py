# GOAL: Sum all integers from 1 to n.

def sum_to_n(n):
    total = 0
    for i in range(n):
        total += i
    return total