def diagonal_sum(matrix):
    total = 0
    for i in range(len(matrix)):
        # FIX: Access the diagonal element directly
        total += matrix[i][i]
    return total