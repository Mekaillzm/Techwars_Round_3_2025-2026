def can_vote(age):
    if age >= 18:
        return True
    return False