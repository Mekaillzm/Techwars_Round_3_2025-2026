def triangle_area(base, height):
    # FIX: Use 0.5 for float multiplication
    area = 0.5 * base * height 
    return area