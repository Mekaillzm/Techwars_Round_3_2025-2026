def replace_char(s, target, replacement):
    s_list = list(s)
    for i in range(len(s_list)):
        if s_list[i] == target:
            # FIX: Assign TO the list index
            s_list[i] = replacement 
    return "".join(s_list)