def sum_to_n(n):
    total = 0
    # FIX: range goes up to n (exclusive), so use n+1
    for i in range(1, n + 1): 
        total += i
    return total