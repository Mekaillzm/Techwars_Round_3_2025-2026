import sys

# --- Colors ---
GREEN = "\033[32m"
RED = "\033[31m"
RESET = "\033[0m"

# --- Import Delegate Files ---
try:
    import Q1E_triangle
    import Q2E_evencount
    import Q3E_sum
    import Q1M_replace
    import Q2M_Linearsearch
    import Q1H_diagsum
except ImportError as e:
    print(f"{RED}Error: Missing file - {e}{RESET}")
    sys.exit(1)

# --- Helper Functions ---
def print_header(title):
    print("\n========================================")
    print(f"{title} — detailed breakdown:")

def print_footer(score, total):
    print("----------------------------------------")
    if score == total:
        print(f"{GREEN}TOTAL: PASS ({score}/{total}){RESET}")
    else:
        print(f"{RED}TOTAL: FAIL ({score}/{total}){RESET}")
    print("========================================")

def ok_flag(cond):
    return f"{GREEN}PASS{RESET}" if cond else f"{RED}FAIL{RESET}"

# --- Test Cases ---

def run_q1e():
    pts = 0
    try:
        # Bug: (1//2) results in 0
        if abs(Q1E_triangle.triangle_area(10, 5) - 25.0) < 0.1:
            pts = 5
    except Exception: pass

    print_header("Q1E: Triangle Area (Q1E_triangle.py)")
    print(f"  Area(10, 5) -> 25.0 : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)

def run_q2e():
    pts = 0
    try:
        if Q2E_evencount.can_vote(18) is True and Q2E_evencount.can_vote(17) is False:
            pts = 5
    except Exception: pass

    print_header("Q2E: Vote Check (Q2E_evencount.py)")
    print(f"  Age 18 (True), 17 (False) : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)

def run_q3e():
    pts = 0
    try:
        # Bug: range(n) misses the last number
        if Q3E_sum.sum_to_n(5) == 15:
            pts = 5
    except Exception: pass

    print_header("Q3E: Sum 1 to N (Q3E_sum.py)")
    print(f"  Sum(5) -> 15 : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)

def run_q1m():
    pts = 0
    try:
        s = "banana"
        # Bug: Logic assigns to local variable instead of list
        res = Q1M_replace.replace_char(s, 'a', 'o')
        if res == "bonono":
            pts = 5
    except Exception: pass

    print_header("Q1M: Replace Char (Q1M_replace.py)")
    print(f"  'banana' -> 'bonono' : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)

def run_q2m():
    pts = 0
    try:
        # Bug: Returns -1 immediately on mismatch
        if Q2M_Linearsearch.find_index([10, 20, 30], 30) == 2:
            pts = 5
    except Exception: pass

    print_header("Q2M: Linear Search (Q2M_Linearsearch.py)")
    print(f"  Find index of 30 : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)

def run_q1h():
    pts = 0
    try:
        # Bug: Sums entire row
        mat = [[1, 2], [3, 4]]
        if Q1H_diagsum.diagonal_sum(mat) == 5:
            pts = 5
    except Exception: pass

    print_header("Q1H: Diagonal Sum (Q1H_diagsum.py)")
    # FIXED LINE BELOW: used double braces {{ }} to escape the literal brackets
    print(f"  {{1,2}},{{3,4}} -> 5 : {pts}/5 {ok_flag(pts==5)}")
    print_footer(pts, 5)
    
def run_all():
    run_q1e()
    run_q2e()
    run_q3e()
    run_q1m()
    run_q2m()
    run_q1h()

# --- Main Menu ---
def main():
    while True:
        print("\n--- Python Debugging Test Runner ---")
        print(" 1) Q1E_triangle.py")
        print(" 2) Q2E_evencount.py")
        print(" 3) Q3E_sum.py")
        print(" 4) Q1M_replace.py")
        print(" 5) Q2M_Linearsearch.py")
        print(" 6) Q1H_diagsum.py")
        print(" 8) Run All Tests")
        print(" 0) Exit")
        
        choice = input("Enter choice: ")
        
        if choice == '0': break
        elif choice == '1': run_q1e()
        elif choice == '2': run_q2e()
        elif choice == '3': run_q3e()
        elif choice == '4': run_q1m()
        elif choice == '5': run_q2m()
        elif choice == '6': run_q1h()
        elif choice == '8': run_all()
        else: print("Invalid choice")

if __name__ == "__main__":
    main()